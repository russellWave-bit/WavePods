package com.breadwinner.wave

/** Word tidying and number reading, so "forty two" and "42" mean the same, and small mishearings still match. */
object Norm {
    private val leadFillers = listOf(
        "can you", "could you", "would you", "will you", "please", "just", "go ahead and",
        "i want you to", "i want to", "i would like to", "okay", "ok", "now"
    )

    fun clean(s: String): String =
        s.lowercase().replace(Regex("[^a-z0-9' ]"), " ").replace(Regex("\\s+"), " ").trim()

    fun words(s: String): List<String> {
        var t = clean(s)
        var again = true
        while (again) {
            again = false
            for (f in leadFillers) {
                if (t.startsWith("$f ")) { t = t.substring(f.length + 1).trim(); again = true }
            }
        }
        if (t.endsWith(" please")) t = t.removeSuffix(" please")
        return t.split(" ").filter { it.isNotEmpty() }
    }

    private val ones = mapOf(
        "zero" to 0, "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7,
        "eight" to 8, "nine" to 9, "ten" to 10, "eleven" to 11, "twelve" to 12, "thirteen" to 13, "fourteen" to 14,
        "fifteen" to 15, "sixteen" to 16, "seventeen" to 17, "eighteen" to 18, "nineteen" to 19
    )
    private val tens = mapOf(
        "twenty" to 20, "thirty" to 30, "forty" to 40, "fifty" to 50, "sixty" to 60, "seventy" to 70, "eighty" to 80, "ninety" to 90
    )
    private val loose = mapOf("to" to 2, "too" to 2, "for" to 4, "won" to 1, "ate" to 8, "tree" to 3, "free" to 3, "oh" to 0)

    fun number(w: List<String>, allowLoose: Boolean = false): Int? {
        if (w.isEmpty()) return null
        var total = 0
        var cur = 0
        var any = false
        for (x in w) {
            val d = x.toIntOrNull()
            val o = ones[x]
            val t = tens[x]
            when {
                d != null -> { cur += d; any = true }
                o != null -> { cur += o; any = true }
                t != null -> { cur += t; any = true }
                x == "hundred" -> { cur = (if (cur == 0) 1 else cur) * 100; any = true }
                x == "and" -> {}
                allowLoose && loose[x] != null -> { cur += loose[x]!!; any = true }
                else -> return null
            }
        }
        return if (any) total + cur else null
    }

    fun looseNumber(w: List<String>): Int? = number(w, true)

    /** "five minutes", "an hour", "two minutes thirty seconds", "half an hour" -> seconds. */
    fun duration(w: List<String>): Int? {
        var total = 0.0
        var any = false
        val run = ArrayList<String>()
        for (x in w) {
            val unit = when {
                x.startsWith("second") || x == "sec" || x == "secs" -> 1
                x.startsWith("minute") || x == "min" || x == "mins" -> 60
                x.startsWith("hour") || x == "hr" || x == "hrs" -> 3600
                else -> 0
            }
            if (unit > 0) {
                val n: Double = when {
                    run.contains("half") -> 0.5
                    run.isEmpty() || run == listOf("a") || run == listOf("an") -> 1.0
                    else -> (looseNumber(run) ?: return null).toDouble()
                }
                total += n * unit
                run.clear()
                any = true
            } else if (x != "and" && x != "for") run.add(x)
        }
        if (!any && run.isNotEmpty()) {
            val n = looseNumber(run) ?: return null
            return n * 60
        }
        if (run.isNotEmpty()) return null
        return if (any) total.toInt() else null
    }

    /** "seven thirty p m", "half past six", "quarter to eight" -> hour and minute in 24h. */
    fun clock(words: List<String>): Pair<Int, Int>? {
        var w = words.filter { it != "at" && it != "for" && it != "o'clock" && it != "oclock" }
        var pm = false
        var am = false
        val keep = ArrayList<String>()
        var i = 0
        while (i < w.size) {
            val x = w[i]
            if (x == "pm" || x == "p.m") { pm = true }
            else if (x == "am" || x == "a.m") { am = true }
            else if ((x == "p" || x == "a") && i + 1 < w.size && w[i + 1] == "m") { if (x == "p") pm = true else am = true; i++ }
            else keep.add(x)
            i++
        }
        w = keep
        if (w.isEmpty()) return null
        var h: Int
        var m = 0
        if (w[0] == "half" && w.size >= 3 && w[1] == "past") {
            h = number(w.drop(2)) ?: return null; m = 30
        } else if (w[0] == "quarter" && w.size >= 3 && w[1] == "past") {
            h = number(w.drop(2)) ?: return null; m = 15
        } else if (w[0] == "quarter" && w.size >= 3 && w[1] == "to") {
            h = (number(w.drop(2)) ?: return null) - 1; m = 45
        } else {
            var found: Pair<Int, Int>? = null
            for (s in 1..minOf(2, w.size)) {
                val hh = number(w.subList(0, s)) ?: continue
                if (hh !in 0..24) continue
                val rest = w.subList(s, w.size)
                val mm: Int = if (rest.isEmpty()) 0
                else if (rest[0] == "oh" || rest[0] == "zero") (number(rest.drop(1)) ?: continue)
                else (number(rest) ?: continue)
                if (mm !in 0..59) continue
                found = hh to mm
            }
            val f = found ?: return null
            h = f.first; m = f.second
        }
        if (pm && h < 12) h += 12
        if (am && h == 12) h = 0
        if (!pm && !am && h in 1..12) {
            val now = java.util.Calendar.getInstance()
            val nowMin = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
            val a = (h % 12) * 60 + m
            val b = a + 12 * 60
            val da = (a - nowMin + 1440) % 1440
            val db = (b - nowMin + 1440) % 1440
            h = if (da <= db) h % 12 else (h % 12) + 12
        }
        if (h > 23) h %= 24
        return h to m
    }

    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    fun sim(a: String, b: String): Float {
        val x = a.replace(" ", "")
        val y = b.replace(" ", "")
        if (x.isEmpty() || y.isEmpty()) return 0f
        return 1f - lev(x, y).toFloat() / maxOf(x.length, y.length)
    }

    fun soundex(s: String): String {
        val t = s.lowercase().filter { it in 'a'..'z' }
        if (t.isEmpty()) return ""
        val codes = "01230120022455012623010202"
        val sb = StringBuilder().append(t[0].uppercaseChar())
        var last = codes[t[0] - 'a']
        for (k in 1 until t.length) {
            val c = codes[t[k] - 'a']
            if (c != '0' && c != last) sb.append(c)
            if (t[k] != 'h' && t[k] != 'w') last = c
            if (sb.length == 4) break
        }
        while (sb.length < 4) sb.append('0')
        return sb.toString()
    }

    /** How well does what you said fit a name. Spelling and sound both count. */
    fun nameScore(said: String, name: String): Float {
        val a = clean(said)
        val n = clean(name)
        if (a.isEmpty() || n.isEmpty()) return 0f
        var best = sim(a, n)
        for (tok in n.split(" ")) {
            if (tok.isEmpty()) continue
            best = maxOf(best, sim(a, tok) * 0.98f)
            if (soundex(tok) == soundex(a.replace(" ", "")) && tok[0] == a[0]) best = maxOf(best, 0.84f)
        }
        if (n.replace(" ", "").startsWith(a.replace(" ", ""))) best = maxOf(best, 0.9f)
        if (a.replace(" ", "") == n.replace(" ", "")) best = 1f
        return best
    }

    /**
     * Matches words against a phrase like "whatsapp call {name}" or "message {name} {text}".
     * A blank that is last takes the rest. A blank before a word takes everything up to that word.
     * A blank before another blank takes one word.
     */
    fun match(tpl: String, words: List<String>): Map<String, String>? {
        val t = tpl.trim().split(Regex("\\s+")).filter { x -> x.isNotEmpty() }
        val out = LinkedHashMap<String, String>()
        return if (go(t.map { if (it.startsWith("{")) it else clean(it) }, 0, words, 0, out)) out else null
    }

    private fun isBlank(t: String) = t.startsWith("{") && t.endsWith("}")

    private fun lit(tok: String, w: String): Boolean =
        tok == w || (tok.length >= 6 && lev(tok, w) <= 1)

    private fun go(t: List<String>, i: Int, w: List<String>, j: Int, out: MutableMap<String, String>): Boolean {
        if (i == t.size) return j == w.size
        val tok = t[i]
        if (!isBlank(tok)) {
            if (j >= w.size || !lit(tok, w[j])) return false
            return go(t, i + 1, w, j + 1, out)
        }
        val key = tok.substring(1, tok.length - 1)
        if (i == t.size - 1) {
            if (j >= w.size) return false
            out[key] = w.subList(j, w.size).joinToString(" ")
            return true
        }
        val next = t[i + 1]
        if (isBlank(next)) {
            if (j >= w.size) return false
            out[key] = w[j]
            if (go(t, i + 1, w, j + 1, out)) return true
            out.remove(key)
            return false
        }
        for (k in j + 1..w.size) {
            if (k < w.size && lit(next, w[k])) {
                out[key] = w.subList(j, k).joinToString(" ")
                if (go(t, i + 1, w, k, out)) return true
                out.remove(key)
            }
        }
        return false
    }

    /** Makes dictated words look typed: capital at the start, I, I'm, and spoken punctuation. */
    fun pretty(s: String): String {
        var t = " " + s.trim() + " "
        val punct = listOf(" comma " to ", ", " full stop " to ". ", " period " to ". ", " question mark " to "? ", " exclamation mark " to "! ", " exclamation point " to "! ")
        for ((a, b) in punct) t = t.replace(a, b)
        t = t.trim()
        t = t.replace(Regex("\\s+([,.?!])"), "$1")
        t = t.replace(Regex("\\bi\\b"), "I").replace(Regex("\\bi'(m|ll|ve|d)\\b"), "I'$1")
        if (t.isNotEmpty()) t = t.substring(0, 1).uppercase() + t.substring(1)
        return t
    }
}
