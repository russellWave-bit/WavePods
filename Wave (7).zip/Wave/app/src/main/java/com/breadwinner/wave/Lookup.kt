package com.breadwinner.wave

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.ContactsContract
import androidx.core.content.ContextCompat

class AppRow(val label: String, val pkg: String)
class Person(val name: String, val numbers: List<String>)

/** "When I say mum, I mean Mum Mobile." Your own word list, checked before anything else. */
object Vocab {
    fun alias(said: String): String {
        val c = Norm.clean(said)
        for ((a, b) in Store.vocab) if (Norm.clean(a) == c) return b
        return said
    }
}

object Apps {
    private var cache: List<AppRow> = emptyList()
    private var at = 0L

    fun all(): List<AppRow> {
        val now = System.currentTimeMillis()
        if (cache.isEmpty() || now - at > 60000) {
            val ctx = Store.app
            val pm = ctx.packageManager
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val seen = HashSet<String>()
            val out = ArrayList<AppRow>()
            try {
                for (ri in pm.queryIntentActivities(i, 0)) {
                    val p = ri.activityInfo.packageName
                    if (!seen.add(p)) continue
                    out.add(AppRow(ri.loadLabel(pm).toString(), p))
                }
            } catch (e: Exception) {
            }
            cache = out
            at = now
        }
        return cache
    }

    /** Best app for what you said, with how sure we are (0 to 1). */
    fun find(said: String): Pair<AppRow, Float>? {
        val q = Vocab.alias(said)
        var best: AppRow? = null
        var bs = 0f
        for (a in all()) {
            var s = Norm.nameScore(q, a.label)
            if (a.pkg.equals(q.trim(), true)) s = 1f
            if (s > bs || (s == bs && best != null && a.label.length < best.label.length)) { bs = s; best = a }
        }
        val b = best ?: return null
        return b to bs
    }
}

object Contacts {
    private var cache: List<Person> = emptyList()
    private var at = 0L

    fun granted(): Boolean =
        ContextCompat.checkSelfPermission(Store.app, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun all(): List<Person> {
        if (!granted()) return emptyList()
        val now = System.currentTimeMillis()
        if (cache.isNotEmpty() && now - at < 60000) return cache
        val map = LinkedHashMap<String, MutableList<String>>()
        try {
            val cur = Store.app.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )
            cur?.use {
                while (it.moveToNext()) {
                    val n = it.getString(0) ?: continue
                    val num = it.getString(1) ?: continue
                    map.getOrPut(n) { ArrayList() }.add(num)
                }
            }
        } catch (e: Exception) {
        }
        cache = map.map { Person(it.key, it.value) }
        at = now
        return cache
    }

    fun find(said: String): Pair<Person, Float>? {
        val q = Vocab.alias(said)
        var best: Person? = null
        var bs = 0f
        for (p in all()) {
            val s = Norm.nameScore(q, p.name)
            if (s > bs) { bs = s; best = p }
        }
        val b = best ?: return null
        return b to bs
    }

    /** International digits for WhatsApp, using your country code for numbers that start with 0. */
    fun waNumber(raw: String): String {
        var d = raw.filter { it.isDigit() }
        if (raw.trim().startsWith("+")) return d
        if (d.startsWith("00")) return d.substring(2)
        if (d.startsWith("0")) d = Store.country + d.substring(1)
        return d
    }
}
