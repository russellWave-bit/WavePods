package com.breadwinner.wave

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * Colours you pick from a spectrum (no hex codes).
 * Each choice is saved as "hue,shade,opacity". Nothing saved means the normal colour.
 */
object Colours {
    data class Pick(val h: Float, val t: Float, val a: Float) {
        /** Shade runs black, then the pure colour in the middle, then white. */
        fun argb(): Int {
            val s: Float
            val v: Float
            if (t < 0.5f) { s = 1f; v = t * 2f } else { s = 1f - (t - 0.5f) * 2f; v = 1f }
            return android.graphics.Color.HSVToColor((a * 255f).toInt().coerceIn(0, 255), floatArrayOf(h, s, v))
        }

        fun rgb(): Int = argb() or 0xFF000000.toInt()
        fun color(): Color = Color(argb())
        fun text(): String = "$h,$t,$a"
    }

    fun load(key: String): Pick? {
        val raw = Store.s(key, "")
        if (raw.isEmpty()) return null
        val p = raw.split(",")
        if (p.size != 3) return null
        val h = p[0].toFloatOrNull() ?: return null
        val t = p[1].toFloatOrNull() ?: return null
        val a = p[2].toFloatOrNull() ?: return null
        return Pick(h.coerceIn(0f, 360f), t.coerceIn(0f, 1f), a.coerceIn(0.2f, 1f))
    }

    fun save(key: String, p: Pick?) {
        Store.put(key, p?.text() ?: "")
    }

    // ---- what each colour touches

    /** What you said (the quoted line on the home screen). */
    @Composable
    fun words(): Color = load("c_words")?.color() ?: Ink

    /** What Wave said back: the reply line on the home screen and the floating words. */
    @Composable
    fun reply(): Color = load("c_reply")?.color() ?: Coral

    /** The status line under the Jarvis core. */
    @Composable
    fun status(normal: Color): Color = load("c_status")?.color() ?: normal

    /** Floating words colour, without the opacity (the overlay fades them itself). */
    fun overlayRgb(): Int = load("c_reply")?.rgb() ?: Fx.textColor(Store.textColor)

    fun overlayAlpha(): Float = load("c_reply")?.a ?: 1f

    /** Glow colours for the ring, the screen edges and the halo behind floating words. Null means use the theme. */
    fun ringPalette(): IntArray? {
        val p = load("c_glow") ?: return null
        val base = p.rgb()
        return intArrayOf(base, shift(base, 24f), shift(base, -24f))
    }

    fun glowAlpha(): Float = load("c_glow")?.a ?: 1f

    /** The eye's colour. Normal follows the glow colour. */
    fun eyeRgb(): Int = load("c_eye")?.rgb() ?: Fx.ringPal()[0]

    fun eyeAlpha(): Float = load("c_eye")?.a ?: 1f

    private fun shift(c: Int, deg: Float): Int {
        val hsv = FloatArray(3)
        android.graphics.Color.colorToHSV(c, hsv)
        hsv[0] = (hsv[0] + deg + 360f) % 360f
        return android.graphics.Color.HSVToColor(hsv)
    }
}

/** One row: a colour dot and a name. Tap it to open the spectrum. */
@Composable
fun ColourPick(title: String, sub: String, key: String, fallback: Color, onChange: () -> Unit = {}) {
    var open by remember { mutableStateOf(false) }
    val cur = Colours.load(key)
    Column(Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().clickable { open = !open }.padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(30.dp).clip(CircleShape).background(cur?.color() ?: fallback).border(1.dp, Hair, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Tx(title, 14)
                if (sub.isNotEmpty()) Tx(sub, 12, Mute, FontWeight.Normal)
            }
            Tx(if (cur == null) "Normal" else "Mine", 12, Mute, FontWeight.Normal)
        }
        if (open) {
            val p = cur ?: Colours.Pick(200f, 0.75f, 1f)
            Strip(Brush.horizontalGradient((0..6).map { Color.hsv(it * 60f, 1f, 1f) }), p.h / 360f) {
                Colours.save(key, p.copy(h = it * 360f)); onChange()
            }
            Spacer(Modifier.height(8.dp))
            Strip(Brush.horizontalGradient(listOf(Color.Black, Color.hsv(p.h, 1f, 1f), Color.White)), p.t) {
                Colours.save(key, p.copy(t = it)); onChange()
            }
            SliderRow("Opacity", p.a, 0.2f..1f, (p.a * 100).toInt().toString() + "%") {
                Colours.save(key, p.copy(a = it)); onChange()
            }
            Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
                Btn("Back to normal") { Colours.save(key, null); onChange() }
                Btn("Done", filled = true) { open = false }
            }
            Spacer(Modifier.height(6.dp))
        }
    }
}

/** A coloured bar you tap or drag along. */
@Composable
private fun Strip(brush: Brush, pos: Float, onPos: (Float) -> Unit) {
    val latest by rememberUpdatedState(onPos)
    val shape = RoundedCornerShape(15.dp)
    Box(
        Modifier.fillMaxWidth().height(30.dp).clip(shape).background(brush).border(1.dp, Hair, shape)
            .pointerInput(Unit) {
                detectTapGestures { o -> latest((o.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    latest((change.position.x / size.width).coerceIn(0f, 1f))
                }
            }
            .drawBehind {
                drawCircle(
                    Color.White, radius = size.height / 2f - 2.dp.toPx(),
                    center = Offset(pos * size.width, size.height / 2f), style = Stroke(3.dp.toPx())
                )
            }
    )
}
