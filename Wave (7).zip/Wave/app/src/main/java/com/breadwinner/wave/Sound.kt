package com.breadwinner.wave

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.AudioRecord
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AutomaticGainControl
import android.media.audiofx.NoiseSuppressor
import android.os.Build
import android.os.Handler
import android.os.Looper

/**
 * Sound plumbing around the ears:
 *  - turns other apps' music down while you talk to Wave, and back up after
 *  - uses your earbuds' mic when they're connected (if you switch it on)
 *  - switches on the phone's own call-style noise filter and echo cancelling
 */
object Sound {
    private var am: AudioManager? = null
    private var focus: AudioFocusRequest? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile var earbudsInUse = false

    fun init(c: Context) {
        if (am == null) am = c.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }

    // ---- lower the music

    private val release = Runnable { releaseNow() }

    /** Music and videos go quiet while you speak and while Wave answers. */
    fun duck() {
        if (!Store.b("duck", true)) return
        val a = am ?: return
        main.removeCallbacks(release)
        if (focus != null) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setWillPauseWhenDucked(false)
            .build()
        try {
            if (a.requestAudioFocus(req) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED) focus = req
        } catch (e: Exception) { }
    }

    /** Music comes back after a short pause, unless Wave is still busy. */
    fun unduckSoon(ms: Long = 900) {
        main.removeCallbacks(release)
        main.postDelayed(release, ms)
    }

    private fun releaseNow() {
        if (Speaker.busy() || Brain.wantsFull()) { unduckSoon(800); return }
        val a = am ?: return
        val f = focus ?: return
        try { a.abandonAudioFocusRequest(f) } catch (e: Exception) { }
        focus = null
    }

    // ---- earbuds mic

    /** Points the mic at your earbuds if they're connected and you've switched this on. True if it worked. */
    fun routeToEarbuds(): Boolean {
        val a = am ?: return false
        if (!Store.b("budsmic", false)) { stopEarbuds(); return false }
        return try {
            if (Build.VERSION.SDK_INT >= 31) {
                val dev = a.availableCommunicationDevices.firstOrNull { it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO }
                if (dev == null) { stopEarbuds(); false } else {
                    a.mode = AudioManager.MODE_IN_COMMUNICATION
                    earbudsInUse = a.setCommunicationDevice(dev)
                    earbudsInUse
                }
            } else {
                @Suppress("DEPRECATION")
                if (!a.isBluetoothScoAvailableOffCall) return false
                @Suppress("DEPRECATION")
                a.startBluetoothSco()
                @Suppress("DEPRECATION")
                a.isBluetoothScoOn = true
                earbudsInUse = true
                true
            }
        } catch (e: Exception) {
            earbudsInUse = false
            false
        }
    }

    fun stopEarbuds() {
        val a = am ?: return
        if (!earbudsInUse) return
        try {
            if (Build.VERSION.SDK_INT >= 31) a.clearCommunicationDevice()
            else {
                @Suppress("DEPRECATION")
                a.stopBluetoothSco()
                @Suppress("DEPRECATION")
                a.isBluetoothScoOn = false
            }
            a.mode = AudioManager.MODE_NORMAL
        } catch (e: Exception) { }
        earbudsInUse = false
    }

    // ---- the phone's own noise filter

    private var ns: NoiseSuppressor? = null
    private var aec: AcousticEchoCanceler? = null
    private var agc: AutomaticGainControl? = null

    /** True when the call-style filter is on, so Wave's own voice is cancelled out of the mic. */
    fun filterOn(): Boolean = Store.b("phonefilter", true) || earbudsInUse

    fun attachEffects(rec: AudioRecord) {
        releaseEffects()
        if (!filterOn()) return
        val id = rec.audioSessionId
        try { if (NoiseSuppressor.isAvailable()) ns = NoiseSuppressor.create(id)?.also { it.enabled = true } } catch (e: Exception) { }
        try { if (AcousticEchoCanceler.isAvailable()) aec = AcousticEchoCanceler.create(id)?.also { it.enabled = true } } catch (e: Exception) { }
        try { if (AutomaticGainControl.isAvailable()) agc = AutomaticGainControl.create(id)?.also { it.enabled = true } } catch (e: Exception) { }
    }

    fun releaseEffects() {
        try { ns?.release() } catch (e: Exception) { }
        try { aec?.release() } catch (e: Exception) { }
        try { agc?.release() } catch (e: Exception) { }
        ns = null; aec = null; agc = null
    }
}
