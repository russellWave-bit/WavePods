package com.breadwinner.wavepods

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Pods.init(applicationContext)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = P.accent)) {
                WavePodsApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (PodsService.hasPerms(this) && Prefs.b("run", true) && PodsService.inst == null) PodsService.start(this)
    }
}
