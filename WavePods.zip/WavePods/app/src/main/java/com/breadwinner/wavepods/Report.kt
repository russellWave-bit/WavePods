package com.breadwinner.wavepods

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.widget.Toast
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Draws a clean picture of one set of pods and hands it to the share sheet. */
object Report {
    fun share(c: Context, r: Reading) {
        try {
            val w = 1080
            val h = 800
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val cv = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            val bg = P.bg.toArgb()
            val surface = P.surface.toArgb()
            val ink = P.text.toArgb()
            val mute = P.mute.toArgb()
            val line = P.line.toArgb()
            val track = P.track.toArgb()
            p.color = bg
            cv.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)

            val shop = Prefs.s("shop", "").trim()
            p.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            p.color = ink
            p.textSize = 54f
            cv.drawText("Pair report", 60f, 100f, p)
            p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            p.color = mute
            p.textSize = 30f
            val date = SimpleDateFormat("d MMM yyyy, HH:mm", Locale.getDefault()).format(Date())
            cv.drawText((if (shop.isNotEmpty()) "$shop  ·  " else "") + date, 60f, 150f, p)
            p.color = ink
            p.textSize = 36f
            cv.drawText(r.model, 60f, 215f, p)

            p.color = surface
            cv.drawRoundRect(60f, 250f, w - 60f, 700f, 18f, 18f, p)
            val cols = listOf(Triple("Left", r.left.pct, status(r.left)), Triple("Right", r.right.pct, status(r.right)), Triple("Case", r.casePct, if (r.caseCharging) "Charging" else ""))
            val cw = (w - 120f) / 3f
            for ((i, col) in cols.withIndex()) {
                val x = 60f + cw * i + 36f
                p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                p.color = mute
                p.textSize = 30f
                cv.drawText(col.first, x, 310f, p)
                p.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                p.textSize = 120f
                p.color = lvl(col.second).toArgb()
                cv.drawText(if (col.second != null) col.second.toString() + "%" else "--", x, 450f, p)
                val on = ((col.second ?: 0) + 5) / 10
                for (k in 0 until 10) {
                    p.color = if (k < on) lvl(col.second).toArgb() else track
                    val bx = x + k * ((cw - 90f) / 10f)
                    cv.drawRect(bx, 490f, bx + (cw - 90f) / 10f - 5f, 530f, p)
                }
                p.typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                p.color = ink
                p.textSize = 30f
                cv.drawText(col.third, x, 590f, p)
                if (i > 0) {
                    p.color = line
                    cv.drawRect(60f + cw * i, 280f, 60f + cw * i + 2f, 670f, p)
                }
            }
            p.color = mute
            p.textSize = 24f
            cv.drawText("Read from the pods' own Bluetooth broadcast. Steps of 10%. Made with WavePods.", 60f, 760f, p)

            val f = File(c.cacheDir, "wavepods-report.png")
            FileOutputStream(f).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
            val uri = FileProvider.getUriForFile(c, c.packageName + ".files", f)
            val send = Intent(Intent.ACTION_SEND)
                .setType("image/png")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            c.startActivity(Intent.createChooser(send, "Share report").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
            Toast.makeText(c, "Couldn't make the report: " + (e.message ?: ""), Toast.LENGTH_LONG).show()
        }
    }

    private fun status(s: Side): String = when {
        s.pct == null -> "Not reporting"
        s.charging -> "Charging"
        s.inEar -> "In ear"
        else -> "Out of ear"
    }
}
