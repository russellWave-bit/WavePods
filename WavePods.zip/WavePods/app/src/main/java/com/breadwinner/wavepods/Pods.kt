package com.breadwinner.wavepods

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Small settings store. Everything is kept as text and read back with a default. */
object Prefs {
    private var sp: SharedPreferences? = null
    val m = mutableStateMapOf<String, String>()

    fun init(c: Context) {
        if (sp != null) return
        val p = c.applicationContext.getSharedPreferences("wavepods", 0)
        sp = p
        for ((k, v) in p.all) m[k] = v.toString()
    }

    fun s(k: String, d: String): String = m[k] ?: d
    fun i(k: String, d: Int): Int = m[k]?.toIntOrNull() ?: d
    fun b(k: String, d: Boolean): Boolean = m[k]?.let { it == "1" } ?: d

    fun put(k: String, v: Any) {
        val str = if (v is Boolean) (if (v) "1" else "0") else v.toString()
        m[k] = str
        sp?.edit()?.putString(k, str)?.apply()
    }
}

/** One side of the pods: a bud. pct is null when the bud isn't reporting. */
data class Side(val pct: Int?, val charging: Boolean, val inEar: Boolean)

data class Reading(
    val model: String,
    val left: Side,
    val right: Side,
    val casePct: Int?,
    val caseCharging: Boolean,
    val rssi: Int,
    val at: Long,
    val code: Int = 0,
    val color: Int = -1,
    val addr: String = ""
)

/** Reads the little broadcast that AirPods (and the copies that imitate them) send out. */
object Decode {
    private fun nib(v: Int): Int? = if (v in 0..10) v * 10 else null

    fun modelName(code: Int): String = when (code) {
        0x0220 -> "AirPods (1st gen)"
        0x0F20 -> "AirPods (2nd gen)"
        0x1320 -> "AirPods (3rd gen)"
        0x1920 -> "AirPods (4th gen)"
        0x0E20 -> "AirPods Pro"
        0x1420 -> "AirPods Pro (2nd gen)"
        0x0A20 -> "AirPods Max"
        0x0B20 -> "Powerbeats Pro"
        0x0C20 -> "Beats Solo Pro"
        else -> "AirPods-style pods"
    }

    /** d is the data that follows Apple's company id in the broadcast. */
    fun parse(d: ByteArray, rssi: Int, now: Long): Reading? {
        if (d.size < 9 || d[0].toInt() != 0x07) return null
        fun u(i: Int): Int = d[i].toInt() and 0xFF
        val code = (u(3) shl 8) or u(4)
        val color = if (d.size > 9) u(9) else -1
        val model = modelName(code)
        val status = u(5)
        val pods = u(6)
        val flags = u(7)
        val flip = (status and 0x20) == 0
        val hi = (pods shr 4) and 0xF
        val lo = pods and 0xF
        val ch = (flags shr 4) and 0xF
        val hiSide = Side(nib(hi), (ch and 2) != 0, (status and 0x08) != 0)
        val loSide = Side(nib(lo), (ch and 1) != 0, (status and 0x02) != 0)
        var left = if (flip) hiSide else loSide
        var right = if (flip) loSide else hiSide
        if (Prefs.b("swap", false)) { val t = left; left = right; right = t }
        return Reading(model, left, right, nib(flags and 0xF), (ch and 4) != 0, rssi, now, code, color)
    }
}

/** Pods you have named. They are matched by model and colour, because the radio address keeps changing. */
object Saved {
    data class Item(val name: String, val code: Int, val color: Int)

    fun all(): List<Item> {
        val out = ArrayList<Item>()
        for (line in Prefs.s("saved", "").split("\n")) {
            if (line.isBlank()) continue
            val p = line.split("|")
            if (p.size < 3) continue
            val code = p[1].toIntOrNull() ?: continue
            out.add(Item(p[0], code, p[2].toIntOrNull() ?: -1))
        }
        return out
    }

    private fun write(items: List<Item>) {
        Prefs.put("saved", items.joinToString("\n") { it.name + "|" + it.code + "|" + it.color })
    }

    fun add(name: String, code: Int, color: Int) {
        val clean = name.replace("|", " ").replace("\n", " ").trim()
        if (clean.isEmpty()) return
        val list = all().filter { !it.name.equals(clean, true) }.toMutableList()
        list.add(Item(clean, code, color))
        write(list)
        Prefs.put("track", clean)
    }

    fun remove(name: String) {
        write(all().filter { it.name != name })
        if (Prefs.s("track", "") == name) Prefs.put("track", "")
    }

    fun active(): Item? {
        val t = Prefs.s("track", "")
        if (t.isEmpty()) return null
        return all().firstOrNull { it.name == t }
    }
}

/** Keeps the last few readings of one number and shows the middle one, so it doesn't jump about. */
private class Hist(val n: Int = 5) {
    private val l = ArrayList<Int>()
    fun reset() { l.clear() }
    fun add(v: Int?): Int? {
        if (v == null) { l.clear(); return null }
        l.add(v)
        if (l.size > n) l.removeAt(0)
        return l.sorted()[l.size / 2]
    }
}

/** Everything the screens, the notification and the widget read from. */
object Pods {
    var reading by mutableStateOf<Reading?>(null)
    var rssiSmooth by mutableStateOf(-100)
    var running by mutableStateOf(false)
    var status by mutableStateOf("Not scanning")
    var single by mutableStateOf<Pair<String, Int>?>(null)
    var tick by mutableStateOf(0L)
    var nearby by mutableStateOf(0)
    var shop by mutableStateOf<List<Reading>>(emptyList())
    var lockAddr by mutableStateOf<String?>(null)
    private var manual = false
    private val shopSeen = HashMap<String, Reading>()
    private var lastShop = 0L
    var dbgApple by mutableStateOf(0)
    var dbgPods by mutableStateOf(0)
    var dbgTypes by mutableStateOf("")
    var dbgHex by mutableStateOf("")
    var dbgList by mutableStateOf<List<String>>(emptyList())
    private val typeCount = HashMap<Int, Int>()

    private val main = Handler(Looper.getMainLooper())
    private val seen = HashMap<String, Reading>()
    private val hL = Hist()
    private val hR = Hist()
    private val hC = Hist()
    private var lastAt = 0L
    private var rssiInit = false
    lateinit var app: Context

    fun init(c: Context) {
        app = c.applicationContext
        Prefs.init(app)
    }

    fun minRssi(): Int = when (Prefs.s("range", "near")) {
        "room" -> -72
        "far" -> -90
        else -> -58
    }

    /** Called for every broadcast heard. Works out which pods are the closest and updates the state. */
    fun onScan(addr: String, data: ByteArray, rssi: Int) {
        val now = System.currentTimeMillis()
        main.post {
            dbgApple++
            if (data.isNotEmpty()) {
                val t = data[0].toInt() and 0xFF
                typeCount[t] = (typeCount[t] ?: 0) + 1
                dbgTypes = typeCount.entries.sortedByDescending { e -> e.value }.take(5)
                    .joinToString("  ") { e -> "type " + e.key.toString(16) + " x" + e.value }
                if (t == 0x07) {
                    val line = addr.takeLast(5) + "  " + rssi + "dBm  " +
                        data.take(12).joinToString(" ") { b -> "%02x".format(b.toInt() and 0xFF) }
                    dbgList = (listOf(line) + dbgList).take(8)
                }
                if (t == 0x07 || dbgHex.isEmpty()) {
                    dbgHex = data.take(32).joinToString(" ") { b -> "%02x".format(b.toInt() and 0xFF) } + "  (" + rssi + " dBm)"
                }
            }
        }
        val r = Decode.parse(data, rssi, now) ?: return
        main.post {
            dbgPods++
            val withAddr = r.copy(addr = addr)
            shopSeen[addr] = withAddr
            if (now - lastShop > 600) {
                lastShop = now
                val si = shopSeen.entries.iterator()
                while (si.hasNext()) if (now - si.next().value.at > 10000) si.remove()
                shop = shopSeen.values.sortedByDescending { x -> x.rssi }
            }
            val sv = Saved.active()
            if (sv != null && !(r.code == sv.code && (sv.color < 0 || r.color == sv.color))) {
                status = "Looking for " + sv.name + "..."
                return@post
            }
            seen[addr] = withAddr
            val iter = seen.entries.iterator()
            while (iter.hasNext()) if (now - iter.next().value.at > 6000) iter.remove()
            val close = seen.filter { e -> e.value.rssi >= minRssi() }
            nearby = close.size
            val strongest = close.entries.maxByOrNull { e -> e.value.rssi }
            // stick to one set of pods so numbers from other people's pods don't mix in
            val la = lockAddr
            var pick: String? = la
            if (pick == null || !seen.containsKey(pick)) {
                pick = strongest?.key
                manual = false
            } else if (!manual && strongest != null && strongest.key != pick) {
                val cur = seen[pick]
                if (cur != null && strongest.value.rssi > cur.rssi + 12) pick = strongest.key
            }
            if (pick == null) {
                status = "Pods heard, but too far away. Hold them next to the phone."
                return@post
            }
            if (pick != lockAddr) {
                lockAddr = pick
                hL.reset(); hR.reset(); hC.reset()
            }
            val best = seen[pick] ?: return@post
            val appeared = reading == null || now - lastAt > 45000
            lastAt = now
            val sl = Side(hL.add(best.left.pct), best.left.charging, best.left.inEar)
            val sr = Side(hR.add(best.right.pct), best.right.charging, best.right.inEar)
            val cp = hC.add(best.casePct)
            val out = Reading(best.model, sl, sr, cp, best.caseCharging, best.rssi, now, best.code, best.color, best.addr)
            reading = out
            rssiSmooth = if (!rssiInit) best.rssi else (rssiSmooth * 0.7f + best.rssi * 0.3f).toInt()
            rssiInit = true
            status = "Listening to " + best.model
            Notes.check(app, out, appeared)
            History.add(out)
        }
    }

    /** True while the last reading is recent enough to trust. */
    fun fresh(): Boolean {
        val r = reading ?: return false
        return System.currentTimeMillis() - r.at < 30000
    }

    /** Track one particular set of pods, picked from Shop mode. */
    fun lockTo(addr: String) {
        main.post {
            lockAddr = addr
            manual = true
            hL.reset(); hR.reset(); hC.reset()
            rssiInit = false
            reading = null
        }
    }

    fun clear() {
        reading = null
        seen.clear()
        manual = false
        lockAddr = null
        nearby = 0
        rssiInit = false
    }

    /** Fallback for pairs that don't broadcast: ask the phone for the one battery number it knows. */
    @SuppressLint("MissingPermission")
    fun pollSingle() {
        try {
            val ad: BluetoothAdapter = (app.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter ?: return
            ad.getProfileProxy(app, object : BluetoothProfile.ServiceListener {
                override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                    var found: Pair<String, Int>? = null
                    try {
                        for (d in proxy.connectedDevices) {
                            val lv = try {
                                BluetoothDevice::class.java.getMethod("getBatteryLevel").invoke(d) as Int
                            } catch (e: Throwable) { -1 }
                            if (lv in 0..100) {
                                found = Pair(try { d.name ?: "Bluetooth device" } catch (e: Throwable) { "Bluetooth device" }, lv)
                                break
                            }
                        }
                    } catch (e: Throwable) { }
                    main.post { single = found }
                    try { ad.closeProfileProxy(profile, proxy) } catch (e: Throwable) { }
                }

                override fun onServiceDisconnected(profile: Int) {}
            }, BluetoothProfile.HEADSET)
        } catch (e: Throwable) { }
    }
}
