package com.breadwinner.wavepods

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

fun pctText(p: Int?): String = if (p == null) "--" else "$p%"

fun summary(r: Reading?, fresh: Boolean): String {
    if (r == null || !fresh) return "No pods nearby"
    var s = "L " + pctText(r.left.pct) + "  ·  R " + pctText(r.right.pct)
    if (r.casePct != null) s += "  ·  Case " + pctText(r.casePct)
    return s
}

fun levelColor(p: Int?): Int = when {
    p == null -> Color.parseColor("#A59FD6")
    p <= 20 -> Color.parseColor("#FF5A5F")
    p <= 50 -> Color.parseColor("#FFC53D")
    else -> Color.parseColor("#34D98A")
}

/** Alerts and pop-ups. */
object Notes {
    const val CH_STATUS = "status"
    const val CH_ALERT = "alerts"
    private var lowL = false
    private var lowR = false

    fun channels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_STATUS, "Pods battery", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Alerts and pop-ups", NotificationManager.IMPORTANCE_HIGH))
    }

    fun open(c: Context): PendingIntent =
        PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun canPost(c: Context): Boolean =
        Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun alert(c: Context, id: Int, title: String, text: String, timeout: Long = 0L) {
        if (!canPost(c)) return
        val b = NotificationCompat.Builder(c, CH_ALERT)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open(c))
        if (timeout > 0) b.setTimeoutAfter(timeout)
        try {
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, b.build())
        } catch (e: Exception) { }
    }

    fun check(c: Context, r: Reading, appeared: Boolean) {
        if (appeared && Prefs.b("popup", true)) {
            alert(c, 3, "Your pods are here", summary(r, true), 8000L)
        }
        if (!Prefs.b("alerts", true)) return
        val th = Prefs.i("low", 20)
        val l = r.left.pct
        val rr = r.right.pct
        if (l != null && !r.left.charging && l <= th) {
            if (!lowL) { lowL = true; alert(c, 10, "Left pod is low", "Left is at $l%. Time to charge.") }
        } else if (l == null || r.left.charging || l > th + 10) lowL = false
        if (rr != null && !r.right.charging && rr <= th) {
            if (!lowR) { lowR = true; alert(c, 11, "Right pod is low", "Right is at $rr%. Time to charge.") }
        } else if (rr == null || r.right.charging || rr > th + 10) lowR = false
    }
}

class PodsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        Pods.init(context)
        WidgetUpdater.update(context)
    }
}

object WidgetUpdater {
    fun update(c: Context) {
        try {
            val mgr = AppWidgetManager.getInstance(c)
            val ids = mgr.getAppWidgetIds(ComponentName(c, PodsWidget::class.java))
            if (ids.isEmpty()) return
            val r = Pods.reading
            val ok = Pods.fresh()
            val rv = RemoteViews(c.packageName, R.layout.widget_pods)
            rv.setTextViewText(R.id.w_t, if (ok && r != null) r.model else "WavePods · no pods nearby")
            rv.setTextViewText(R.id.w_l, pctText(if (ok) r?.left?.pct else null))
            rv.setTextViewText(R.id.w_r, pctText(if (ok) r?.right?.pct else null))
            rv.setTextViewText(R.id.w_c, pctText(if (ok) r?.casePct else null))
            rv.setTextColor(R.id.w_l, levelColor(if (ok) r?.left?.pct else null))
            rv.setTextColor(R.id.w_r, levelColor(if (ok) r?.right?.pct else null))
            rv.setTextColor(R.id.w_c, levelColor(if (ok) r?.casePct else null))
            rv.setOnClickPendingIntent(R.id.w_root, Notes.open(c))
            mgr.updateAppWidget(ids, rv)
        } catch (e: Exception) { }
    }
}

/** Keeps listening for the pods' broadcasts, even with the app closed. */
class PodsService : Service() {
    companion object {
        @Volatile var inst: PodsService? = null

        fun hasPerms(c: Context): Boolean {
            return if (Build.VERSION.SDK_INT >= 31)
                ContextCompat.checkSelfPermission(c, Manifest.permission.BLUETOOTH_SCAN) == PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(c, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED
            else ContextCompat.checkSelfPermission(c, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        }

        fun start(c: Context) {
            if (!hasPerms(c)) return
            try {
                ContextCompat.startForegroundService(c, Intent(c, PodsService::class.java))
            } catch (e: Exception) {
                Pods.status = "Android wouldn't start the scanner. Open WavePods and tap Start."
            }
        }

        fun stop(c: Context) {
            Prefs.put("run", false)
            c.stopService(Intent(c, PodsService::class.java))
        }

        fun rescan() {
            Handler(Looper.getMainLooper()).post { inst?.restartScan() }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var cb: ScanCallback? = null
    private var lastText = ""

    private val beat = object : Runnable {
        override fun run() {
            Pods.tick = System.currentTimeMillis()
            if (!Pods.fresh()) Pods.pollSingle()
            refreshOutputs()
            main.postDelayed(this, 5000)
        }
    }

    private fun build(text: String): Notification {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, PodsService::class.java).setAction("stop"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, Notes.CH_STATUS)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle("WavePods")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(Notes.open(this))
            .addAction(0, "Stop", stop)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        inst = this
        Pods.init(applicationContext)
        Notes.channels(this)
        val n = build("Looking for your pods...")
        try {
            if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
            else startForeground(1, n)
        } catch (e: Exception) {
            Pods.status = "Android wouldn't let the scanner run: " + (e.message ?: "")
            stopSelf()
            return
        }
        Prefs.put("run", true)
        restartScan()
        main.post(beat)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "stop") {
            Prefs.put("run", false)
            stopSelf()
        }
        return START_STICKY
    }

    @Suppress("MissingPermission")
    fun restartScan() {
        stopScan()
        try {
            val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            if (ad == null || !ad.isEnabled) {
                Pods.status = "Bluetooth is off. Turn it on to see your pods."
                Pods.running = false
                return
            }
            val sc = ad.bluetoothLeScanner
            if (sc == null) {
                Pods.status = "Bluetooth isn't ready yet."
                return
            }
            val filter = ScanFilter.Builder()
                .setManufacturerData(0x004C, ByteArray(0), ByteArray(0))
                .build()
            val mode = if (Prefs.s("scan", "saver") == "fast") ScanSettings.SCAN_MODE_LOW_LATENCY else ScanSettings.SCAN_MODE_BALANCED
            val settings = ScanSettings.Builder().setScanMode(mode).build()
            val c = object : ScanCallback() {
                override fun onScanResult(callbackType: Int, result: ScanResult) {
                    val d = result.scanRecord?.getManufacturerSpecificData(0x004C) ?: return
                    Pods.onScan(result.device.address, d, result.rssi)
                }

                override fun onBatchScanResults(results: MutableList<ScanResult>) {
                    for (r in results) onScanResult(0, r)
                }

                override fun onScanFailed(errorCode: Int) {
                    Pods.status = "Scan problem (code $errorCode)"
                    Pods.running = false
                }
            }
            cb = c
            sc.startScan(listOf(filter), settings, c)
            Pods.running = true
            Pods.status = "Looking for your pods..."
        } catch (e: Exception) {
            Pods.status = "Couldn't start scanning: " + (e.message ?: "")
            Pods.running = false
        }
    }

    @Suppress("MissingPermission")
    private fun stopScan() {
        val c = cb ?: return
        try {
            val ad = (getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
            ad?.bluetoothLeScanner?.stopScan(c)
        } catch (e: Exception) { }
        cb = null
    }

    private fun refreshOutputs() {
        val ok = Pods.fresh()
        val text = summary(Pods.reading, ok) +
            (if (!ok) Pods.single?.let { "  ·  " + it.first + " " + it.second + "%" } ?: "" else "")
        if (text != lastText) {
            lastText = text
            try {
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(1, build(text))
            } catch (e: Exception) { }
        }
        WidgetUpdater.update(this)
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        main.removeCallbacks(beat)
        stopScan()
        Pods.running = false
        Pods.status = "Not scanning"
        inst = null
        super.onDestroy()
    }
}
