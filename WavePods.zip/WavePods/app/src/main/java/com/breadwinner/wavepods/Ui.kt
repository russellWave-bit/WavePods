package com.breadwinner.wavepods

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Solid colours only. Dark by default, light if chosen. */
object P {
    val dark: Boolean get() = Prefs.s("theme", "dark") == "dark"
    val bg: Color get() = if (dark) Color(0xFF0D1117) else Color(0xFFF2F4F7)
    val card: Color get() = if (dark) Color(0xFF161B22) else Color(0xFFFFFFFF)
    val line: Color get() = if (dark) Color(0xFF2A313A) else Color(0xFFD8DEE6)
    val text: Color get() = if (dark) Color(0xFFE6EDF3) else Color(0xFF101828)
    val mute: Color get() = if (dark) Color(0xFF8B949E) else Color(0xFF667085)
    val track: Color get() = if (dark) Color(0xFF262D36) else Color(0xFFE4E8EE)
    val green = Color(0xFF3FB950)
    val amber = Color(0xFFD29922)
    val red = Color(0xFFF85149)
    val blue = Color(0xFF2F81F7)
}

fun lvl(p: Int?): Color = when {
    p == null -> P.mute
    p <= 20 -> P.red
    p <= 50 -> P.amber
    else -> P.green
}

@Composable
fun Tx(
    text: String, size: Int = 14, color: Color = P.text,
    weight: FontWeight = FontWeight.Medium, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis)
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(P.card).border(1.dp, P.line, shape).padding(16.dp),
        content = content
    )
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val bg = if (filled) P.blue else P.card
    Box(
        modifier.clip(shape).background(bg).border(1.dp, if (filled) P.blue else P.line, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Tx(text, 14, if (filled) Color.White else if (enabled) P.text else P.mute, FontWeight.SemiBold)
    }
}

@Composable
fun Chip(text: String, color: Color) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(color.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Tx(text, 12, color, FontWeight.SemiBold)
    }
}

@Composable
fun Meter(pct: Int?, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(50)
    Box(modifier.fillMaxWidth().height(10.dp).clip(shape).background(P.track)) {
        val f = ((pct ?: 0).coerceIn(0, 100)) / 100f
        if (f > 0f) Box(Modifier.fillMaxWidth(f).height(10.dp).clip(shape).background(lvl(pct)))
    }
}

@Composable
fun ToggleRow(title: String, sub: String = "", on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Tx(title, 15)
            if (sub.isNotEmpty()) Tx(sub, 12, P.mute, FontWeight.Normal)
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = P.blue, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(P.track).padding(3.dp)) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (i == sel) P.card else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) { Tx(s, 13, if (i == sel) P.text else P.mute, FontWeight.SemiBold) }
        }
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row {
            Tx(title, 14, modifier = Modifier.weight(1f))
            Tx(shown, 13, P.mute, FontWeight.Normal)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = P.blue, activeTrackColor = P.blue, inactiveTrackColor = P.track)
        )
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun Banner(text: String, color: Color, action: String = "", onClick: () -> Unit = {}) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(color.copy(alpha = 0.15f)).border(1.dp, color.copy(alpha = 0.5f), shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Tx(text, 13, P.text, modifier = Modifier.weight(1f))
        if (action.isNotEmpty()) Btn(action, filled = true, onClick = onClick)
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val names = listOf("Pods", "Find", "Settings")
    Row(Modifier.fillMaxWidth().background(P.card).border(1.dp, P.line).navigationBarsPadding()) {
        names.forEachIndexed { i, n ->
            Box(Modifier.weight(1f).clickable { onTab(i) }.padding(vertical = 14.dp), contentAlignment = Alignment.Center) {
                Tx(n, 14, if (i == tab) P.blue else P.mute, if (i == tab) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}
