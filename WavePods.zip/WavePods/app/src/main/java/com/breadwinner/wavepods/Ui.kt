package com.breadwinner.wavepods

import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Solid colours only. Deep indigo ground, three loud signal colours for battery level. */
object P {
    val dark: Boolean get() = Prefs.s("theme", "dark") == "dark"
    val bg: Color get() = if (dark) Color(0xFF17133A) else Color(0xFFF0EDFF)
    val card: Color get() = if (dark) Color(0xFF241F54) else Color(0xFFFFFFFF)
    val line: Color get() = if (dark) Color(0xFF3A3380) else Color(0xFFD9D3F5)
    val text: Color get() = if (dark) Color(0xFFF3F1FF) else Color(0xFF17133A)
    val mute: Color get() = if (dark) Color(0xFFA59FD6) else Color(0xFF6B648F)
    val track: Color get() = if (dark) Color(0xFF362F78) else Color(0xFFE2DDF7)
    val ink = Color(0xFF17133A)
    val green = Color(0xFF34D98A)
    val amber = Color(0xFFFFC53D)
    val red = Color(0xFFFF5A5F)
    val lilac = Color(0xFFB8A8FF)
    val blue = Color(0xFF7B61FF)
}

val Cond = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))

fun lvl(p: Int?): Color = when {
    p == null -> P.mute
    p <= 20 -> P.red
    p <= 50 -> P.amber
    else -> P.green
}

@Composable
fun Tx(
    text: String, size: Int = 14, color: Color = P.text,
    weight: FontWeight = FontWeight.Medium, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE,
    family: FontFamily? = null
) {
    Text(text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier, maxLines = maxLines, overflow = TextOverflow.Ellipsis, fontFamily = family)
}

@Composable
fun Card(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(P.card).padding(16.dp),
        content = content
    )
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, filled: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    val bg = if (filled) P.blue else P.card
    Box(
        modifier.clip(shape).background(bg).border(1.dp, if (filled) P.blue else P.line, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Tx(text, 14, if (filled) Color.White else if (enabled) P.text else P.mute, FontWeight.SemiBold)
    }
}

@Composable
fun Chip(text: String, color: Color) {
    val shape = RoundedCornerShape(50)
    Box(Modifier.clip(shape).background(color.copy(alpha = 0.18f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Tx(text, 12, color, FontWeight.SemiBold)
    }
}

/** Ten blocks, because the pods report battery in steps of ten. */
@Composable
fun Meter(pct: Int?, modifier: Modifier = Modifier, onBlock: Boolean = false) {
    val on = ((pct ?: 0) + 5) / 10
    Row(modifier.fillMaxWidth().height(14.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        for (i in 0 until 10) {
            val filled = i < on
            val c = if (onBlock) {
                if (filled) P.ink else P.ink.copy(alpha = 0.18f)
            } else {
                if (filled) lvl(pct) else P.track
            }
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(c))
        }
    }
}

@Composable
fun ChipSolid(text: String, bg: Color, fg: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(bg).padding(horizontal = 12.dp, vertical = 5.dp)) {
        Tx(text, 12, fg, FontWeight.Bold)
    }
}

@Composable
fun ToggleRow(title: String, sub: String = "", on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Tx(title, 15)
            if (sub.isNotEmpty()) Tx(sub, 12, P.mute, FontWeight.Normal)
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = P.blue, checkedThumbColor = Color.White)
        )
    }
}

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(12.dp)
    Row(Modifier.fillMaxWidth().clip(shape).background(P.track).padding(3.dp)) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(10.dp))
                    .background(if (i == sel) P.card else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 10.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) { Tx(s, 13, if (i == sel) P.text else P.mute, FontWeight.SemiBold) }
        }
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row {
            Tx(title, 14, modifier = Modifier.weight(1f))
            Tx(shown, 13, P.mute, FontWeight.Normal)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = P.blue, activeTrackColor = P.blue, inactiveTrackColor = P.track)
        )
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun Banner(text: String, color: Color, action: String = "", onClick: () -> Unit = {}) {
    val shape = RoundedCornerShape(12.dp)
    Row(
        Modifier.fillMaxWidth().clip(shape).background(color.copy(alpha = 0.15f)).border(1.dp, color.copy(alpha = 0.5f), shape).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Tx(text, 13, P.text, modifier = Modifier.weight(1f))
        if (action.isNotEmpty()) Btn(action, filled = true, onClick = onClick)
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val names = listOf("Pods", "Find", "Settings")
    Row(
        Modifier.fillMaxWidth().background(P.card).navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        names.forEachIndexed { i, n ->
            val on = i == tab
            Box(
                Modifier.weight(1f).clip(RoundedCornerShape(50)).background(if (on) P.blue else Color.Transparent)
                    .clickable { onTab(i) }.padding(vertical = 11.dp),
                contentAlignment = Alignment.Center
            ) {
                Tx(n, 14, if (on) Color.White else P.mute, if (on) FontWeight.Bold else FontWeight.Medium)
            }
        }
    }
}
