package com.breadwinner.wavepods

import android.graphics.Typeface
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Two looks, chosen in Settings.
 * Graphite: charcoal with one amber accent, like an instrument panel.
 * Bone: warm grey paper with ink, colour used only for battery state.
 */
object P {
    val pro: Boolean get() = Prefs.s("look", "graphite") == "graphite"
    val bg: Color get() = if (pro) Color(0xFF121315) else Color(0xFFEBE8E1)
    val surface: Color get() = if (pro) Color(0xFF1B1D20) else Color(0xFFF7F5F0)
    val line: Color get() = if (pro) Color(0xFF2E3136) else Color(0xFFCFCAC0)
    val text: Color get() = if (pro) Color(0xFFECEAE4) else Color(0xFF141414)
    val mute: Color get() = if (pro) Color(0xFF8E9097) else Color(0xFF6E6A62)
    val track: Color get() = if (pro) Color(0xFF2A2D31) else Color(0xFFD9D4CA)
    val accent: Color get() = if (pro) Color(0xFFFF9F1C) else Color(0xFF141414)
    val onAccent: Color get() = if (pro) Color(0xFF121315) else Color(0xFFF7F5F0)
    val good: Color get() = if (pro) Color(0xFF4CD97B) else Color(0xFF1E9E5A)
    val mid: Color get() = if (pro) Color(0xFFF2C94C) else Color(0xFFC98A00)
    val bad: Color get() = if (pro) Color(0xFFFF5C4D) else Color(0xFFD63B2F)
}

val Cond = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))

fun lvl(p: Int?): Color = when {
    p == null -> P.mute
    p <= 20 -> P.bad
    p <= 50 -> P.mid
    else -> P.good
}

@Composable
fun Tx(
    text: String, size: Int = 14, color: Color = P.text,
    weight: FontWeight = FontWeight.Medium, modifier: Modifier = Modifier, maxLines: Int = Int.MAX_VALUE,
    family: FontFamily? = null
) {
    Text(
        text, color = color, fontSize = size.sp, fontWeight = weight, modifier = modifier,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis, fontFamily = family
    )
}

@Composable
fun Panel(modifier: Modifier = Modifier, pad: Dp = 16.dp, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Column(
        modifier.fillMaxWidth().clip(shape).background(P.surface).border(1.dp, P.line, shape).padding(pad),
        content = content
    )
}

@Composable
fun HLine() {
    Box(Modifier.fillMaxWidth().height(1.dp).background(P.line))
}

@Composable
fun Btn(text: String, modifier: Modifier = Modifier, primary: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier.clip(shape).background(if (primary) P.accent else Color.Transparent)
            .border(1.dp, if (primary) P.accent else P.line, shape)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 14.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Tx(text, 14, if (primary) P.onAccent else if (enabled) P.text else P.mute, FontWeight.SemiBold)
    }
}

@Composable
fun StatusLine(text: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(7.dp))
        Tx(text, 13, P.text, FontWeight.Medium)
    }
}

/** Ten ticks, because the pods report battery in steps of ten. */
@Composable
fun Ticks(pct: Int?, modifier: Modifier = Modifier, h: Dp = 20.dp) {
    val on = ((pct ?: 0) + 5) / 10
    Row(modifier.fillMaxWidth().height(h), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        for (i in 0 until 10) {
            Box(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(1.dp))
                    .background(if (i < on) lvl(pct) else P.track)
            )
        }
    }
}

@Composable
fun ToggleRow(title: String, sub: String = "", on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Tx(title, 15)
            if (sub.isNotEmpty()) Tx(sub, 12, P.mute, FontWeight.Normal)
        }
        Switch(
            checked = on, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedTrackColor = P.accent, checkedThumbColor = P.onAccent,
                uncheckedTrackColor = P.track, uncheckedThumbColor = P.mute, uncheckedBorderColor = P.line
            )
        )
    }
}

@Composable
fun Seg(options: List<String>, sel: Int, onSel: (Int) -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Row(Modifier.fillMaxWidth().clip(shape).border(1.dp, P.line, shape)) {
        options.forEachIndexed { i, s ->
            Box(
                Modifier.weight(1f).background(if (i == sel) P.accent else Color.Transparent)
                    .clickable { onSel(i) }.padding(vertical = 11.dp, horizontal = 4.dp),
                contentAlignment = Alignment.Center
            ) { Tx(s, 13, if (i == sel) P.onAccent else P.mute, FontWeight.SemiBold) }
        }
    }
}

@Composable
fun SliderRow(title: String, value: Float, range: ClosedFloatingPointRange<Float>, shown: String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Row {
            Tx(title, 14, modifier = Modifier.weight(1f))
            Tx(shown, 13, P.mute, FontWeight.Normal)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = P.accent, activeTrackColor = P.accent, inactiveTrackColor = P.track)
        )
    }
}

@Composable
fun TextBox(value: String, hint: String, modifier: Modifier = Modifier, onChange: (String) -> Unit) {
    val shape = RoundedCornerShape(6.dp)
    Box(
        modifier.fillMaxWidth().clip(shape).background(P.bg).border(1.dp, P.line, shape).padding(horizontal = 12.dp, vertical = 12.dp)
    ) {
        if (value.isEmpty()) Tx(hint, 14, P.mute, FontWeight.Normal)
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = true,
            textStyle = TextStyle(color = P.text, fontSize = 15.sp),
            cursorBrush = SolidColor(P.accent),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
fun Page(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().statusBarsPadding()
            .verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        content = content
    )
}

@Composable
fun Banner(text: String, color: Color, action: String = "", onClick: () -> Unit = {}) {
    val shape = RoundedCornerShape(8.dp)
    Row(
        Modifier.fillMaxWidth().height(IntrinsicSize.Min).clip(shape).background(P.surface).border(1.dp, P.line, shape)
    ) {
        Box(Modifier.width(4.dp).fillMaxHeight().background(color))
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Tx(text, 13, P.text, modifier = Modifier.weight(1f))
            if (action.isNotEmpty()) {
                Spacer(Modifier.width(10.dp))
                Btn(action, primary = true, onClick = onClick)
            }
        }
    }
}

@Composable
fun BottomBar(tab: Int, onTab: (Int) -> Unit) {
    val names = listOf("Pods", "Shop", "Find", "Settings")
    Column(Modifier.fillMaxWidth().background(P.surface)) {
        HLine()
        Row(Modifier.fillMaxWidth().navigationBarsPadding()) {
            names.forEachIndexed { i, n ->
                val on = i == tab
                Column(Modifier.weight(1f).clickable { onTab(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.fillMaxWidth().height(3.dp).background(if (on) P.accent else Color.Transparent))
                    Spacer(Modifier.height(12.dp))
                    Tx(n, 14, if (on) P.text else P.mute, if (on) FontWeight.Bold else FontWeight.Medium)
                    Spacer(Modifier.height(14.dp))
                }
            }
        }
    }
}
