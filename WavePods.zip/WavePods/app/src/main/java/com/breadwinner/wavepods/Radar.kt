package com.breadwinner.wavepods

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

fun distWord(rssi: Int): String = when {
    rssi >= -52 -> "Very close"
    rssi >= -64 -> "Close"
    rssi >= -76 -> "In the room"
    rssi >= -88 -> "Far"
    else -> "Very far"
}

/** A tilting radar. Signal strength gives the distance, the compass and a slow turn give the direction. */
@Composable
fun FindPage() {
    val ctx = LocalContext.current
    var az by remember { mutableFloatStateOf(0f) }
    var tiltX by remember { mutableFloatStateOf(0f) }
    var tiltY by remember { mutableFloatStateOf(0f) }
    var bearing by remember { mutableFloatStateOf(Float.NaN) }
    val buckets = remember { FloatArray(24) { Float.NaN } }

    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        val rot = FloatArray(9)
        val rot2 = FloatArray(9)
        val ori = FloatArray(3)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                SensorManager.getRotationMatrixFromVector(rot, e.values)
                SensorManager.getOrientation(rot, ori)
                val pitch = Math.toDegrees(ori[1].toDouble()).toFloat()
                val roll = Math.toDegrees(ori[2].toDouble()).toFloat()
                val upright = abs(pitch) > 55f
                var heading = Math.toDegrees(ori[0].toDouble()).toFloat()
                if (upright) {
                    SensorManager.remapCoordinateSystem(rot, SensorManager.AXIS_X, SensorManager.AXIS_Z, rot2)
                    val o2 = FloatArray(3)
                    SensorManager.getOrientation(rot2, o2)
                    heading = Math.toDegrees(o2[0].toDouble()).toFloat()
                }
                heading = (heading + 360f) % 360f
                var d = heading - az
                if (d > 180f) d -= 360f
                if (d < -180f) d += 360f
                az = (az + d * 0.25f + 360f) % 360f
                val tx = if (upright) 0f else (-pitch).coerceIn(-30f, 30f) * 0.6f
                val ty = if (upright) 0f else roll.coerceIn(-30f, 30f) * 0.6f
                tiltX = tiltX * 0.8f + tx * 0.2f
                tiltY = tiltY * 0.8f + ty * 0.2f
            }

            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (sensor != null) sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(listener) }
    }

    // learn which way is strongest as you turn
    LaunchedEffect(Unit) {
        while (true) {
            delay(200)
            val r = Pods.reading
            if (Pods.fresh() && r != null) {
                val idx = ((az / 15f).toInt()).coerceIn(0, 23)
                val cur = buckets[idx]
                buckets[idx] = if (cur.isNaN()) r.rssi.toFloat() else cur * 0.6f + r.rssi * 0.4f
                val known = buckets.filter { x -> !x.isNaN() }
                if (known.size >= 8) {
                    var mi = 0
                    var mv = -200f
                    for (i in 0 until 24) {
                        val b = buckets[i]
                        if (!b.isNaN() && b > mv) { mv = b; mi = i }
                    }
                    val med = known.sorted()[known.size / 2]
                    bearing = if (mv - med >= 5f) mi * 15f + 7.5f else Float.NaN
                }
            }
        }
    }

    // a short buzz when you are very close
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (Prefs.b("buzz", true) && Pods.fresh() && Pods.rssiSmooth >= -50) {
                try {
                    val vib = if (Build.VERSION.SDK_INT >= 31)
                        (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
                    else
                        ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
                    vib.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
                } catch (e: Exception) { }
            }
        }
    }

    val ok = Pods.fresh()
    val v = Pods.rssiSmooth
    val f = if (!ok) 0f else ((v + 100) / 55f).coerceIn(0f, 1f)
    val closeColor = if (f > 0.7f) P.good else if (f > 0.4f) P.mid else P.bad
    var rel = 0f
    if (!bearing.isNaN()) {
        rel = ((bearing - az + 540f) % 360f) - 180f
    }
    val hint = when {
        !ok -> "No signal. Open the case lid or take a bud out."
        f > 0.93f -> "Right here. Look around you."
        !bearing.isNaN() && rel > 20f -> "Turn right"
        !bearing.isNaN() && rel < -20f -> "Turn left"
        !bearing.isNaN() -> "Straight ahead. Walk that way."
        else -> "Turn slowly on the spot to find the direction."
    }

    Page {
        Tx("Find my pods", 28, P.text, FontWeight.Bold)
        Tx("Tilt the phone and turn around. The radar shows how close they are.", 13, P.mute, FontWeight.Normal)

        RadarView(az, tiltX, tiltY, f, if (bearing.isNaN()) Float.NaN else rel, ok, closeColor)

        Panel {
            Tx(if (ok) distWord(v) else "No signal", 44, if (ok) closeColor else P.mute, FontWeight.Bold, family = Cond)
            Spacer(Modifier.height(4.dp))
            Tx(hint, 14, P.text, FontWeight.Medium)
            if (ok) Tx("Signal " + v + " dBm", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Reset sweep") { buckets.fill(Float.NaN); bearing = Float.NaN }
            }
        }

        Panel {
            Tx("What I can hear", 15, P.text, FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Tx("Apple-style broadcasts: " + Pods.dbgApple, 13, P.mute, FontWeight.Normal)
            Tx("Pods broadcasts: " + Pods.dbgPods, 13, P.mute, FontWeight.Normal)
            if (Pods.dbgTypes.isNotEmpty()) Tx(Pods.dbgTypes, 12, P.mute, FontWeight.Normal)
            if (Pods.dbgList.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Tx("Latest pod broadcasts (source, signal, first bytes)", 11, P.mute, FontWeight.SemiBold)
                for (l in Pods.dbgList) Tx(l, 10, P.mute, FontWeight.Normal)
            }
            Spacer(Modifier.height(6.dp))
            Tx("Pods only broadcast when awake: lid open, or a bud out of the case. Walls and bodies weaken the signal, so treat the direction as a guide.", 12, P.mute, FontWeight.Normal)
        }
    }
}

@Composable
fun RadarView(az: Float, tiltX: Float, tiltY: Float, f: Float, rel: Float, ok: Boolean, closeColor: Color) {
    val tr = rememberInfiniteTransition(label = "radar")
    val sweep by tr.animateFloat(0f, 360f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "sweep")
    val pulse by tr.animateFloat(0f, 1f, infiniteRepeatable(tween(1400), RepeatMode.Reverse), label = "pulse")
    val surface = P.surface
    val lineC = P.line
    val mute = P.mute
    val text = P.text
    val accent = P.accent
    androidx.compose.foundation.layout.Box(
        Modifier.fillMaxWidth().aspectRatio(1f).graphicsLayer {
            rotationX = tiltX
            rotationY = tiltY
            cameraDistance = 16f * density
        }
    ) {
        Canvas(Modifier.fillMaxWidth().aspectRatio(1f)) {
            val c = Offset(size.width / 2f, size.height / 2f)
            val rad = min(size.width, size.height) / 2f * 0.94f
            drawCircle(surface, rad, c)
            // distance rings
            for (i in 1..4) {
                drawCircle(lineC, rad * i / 4f, c, style = Stroke(width = 1.5.dp.toPx()))
            }
            // compass ring: turns against your heading, so north stays north
            rotate(-az, c) {
                for (deg in 0 until 360 step 15) {
                    val len = if (deg % 90 == 0) 14.dp.toPx() else 7.dp.toPx()
                    rotate(deg.toFloat(), c) {
                        drawLine(mute, Offset(c.x, c.y - rad), Offset(c.x, c.y - rad + len), 1.5.dp.toPx())
                    }
                }
                val np = Paint(Paint.ANTI_ALIAS_FLAG)
                np.color = accent.toArgb()
                np.textSize = 15.dp.toPx()
                np.typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                np.textAlign = Paint.Align.CENTER
                drawContext.canvas.nativeCanvas.drawText("N", c.x, c.y - rad + 34.dp.toPx(), np)
            }
            // sweep
            rotate(sweep, c) {
                for (i in 0 until 14) {
                    rotate(-i * 2.2f, c) {
                        drawLine(accent.copy(alpha = (0.5f - i * 0.035f).coerceAtLeast(0f)), c, Offset(c.x, c.y - rad), 2.dp.toPx())
                    }
                }
            }
            // the pods
            if (ok) {
                val rf = 1f - f * 0.92f
                if (!rel.isNaN()) {
                    val ang = Math.toRadians(rel.toDouble())
                    val px = c.x + (rf * rad * sin(ang)).toFloat()
                    val py = c.y - (rf * rad * cos(ang)).toFloat()
                    drawCircle(closeColor.copy(alpha = 0.15f + 0.1f * pulse), 30.dp.toPx() + 8.dp.toPx() * pulse, Offset(px, py))
                    drawCircle(closeColor.copy(alpha = 0.35f), 18.dp.toPx(), Offset(px, py))
                    drawCircle(closeColor, 9.dp.toPx(), Offset(px, py))
                } else {
                    drawCircle(
                        closeColor.copy(alpha = 0.35f + 0.4f * pulse), rf * rad, c,
                        style = Stroke(width = 5.dp.toPx())
                    )
                }
            }
            // you
            drawCircle(text, 6.dp.toPx(), c)
            drawLine(text, c, Offset(c.x, c.y - 26.dp.toPx()), 3.dp.toPx())
        }
    }
}
