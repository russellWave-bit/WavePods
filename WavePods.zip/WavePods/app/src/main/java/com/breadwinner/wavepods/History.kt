package com.breadwinner.wavepods

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** A point is saved every two minutes while your pods are in range. */
object History {
    private const val MAX = 360
    private var lastAt = 0L
    var version by mutableIntStateOf(0)

    private fun key(): String = "hist_" + Prefs.s("track", "")

    fun load(): List<LongArray> {
        val s = Prefs.s(key(), "")
        val out = ArrayList<LongArray>()
        if (s.isEmpty()) return out
        for (item in s.split(",")) {
            val p = item.split(":")
            if (p.size < 4) continue
            val a = p[0].toLongOrNull() ?: continue
            out.add(longArrayOf(a, p[1].toLongOrNull() ?: -1L, p[2].toLongOrNull() ?: -1L, p[3].toLongOrNull() ?: -1L))
        }
        return out
    }

    fun add(r: Reading) {
        val now = System.currentTimeMillis()
        if (now - lastAt < 120000L) return
        val l = r.left.pct ?: -1
        val rr = r.right.pct ?: -1
        if (l < 0 && rr < 0) return
        lastAt = now
        val list = load().toMutableList()
        list.add(longArrayOf(now, l.toLong(), rr.toLong(), (r.casePct ?: -1).toLong()))
        while (list.size > MAX) list.removeAt(0)
        Prefs.put(key(), list.joinToString(",") { x -> x.joinToString(":") })
        version++
    }
}

@Composable
fun HistoryPanel() {
    val v = History.version
    val track = Prefs.s("track", "")
    val all = remember(v, track) { History.load() }
    val now = System.currentTimeMillis()
    val t0 = maxOf(now - 12L * 3600000L, if (all.isNotEmpty()) all[0][0] else now)
    val data = all.filter { x -> x[0] >= t0 }
    val cL = P.accent
    val cR = P.text
    val grid = P.line
    Panel {
        Tx("Battery history", 15, P.text, FontWeight.SemiBold)
        Spacer(Modifier.height(10.dp))
        if (data.size < 2) {
            Tx("Collecting. A point is saved every 2 minutes while your pods are in range.", 12, P.mute, FontWeight.Normal)
        } else {
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val w = size.width
                val h = size.height
                val span = maxOf(1L, now - t0).toFloat()
                for (g in listOf(0f, 0.5f, 1f)) {
                    drawLine(grid, Offset(0f, h * (1f - g)), Offset(w, h * (1f - g)), 1.dp.toPx())
                }
                fun plot(sel: Int, col: Color) {
                    val path = Path()
                    var pen = false
                    for (d in data) {
                        val value = d[sel]
                        if (value < 0L) { pen = false; continue }
                        val x = ((d[0] - t0).toFloat() / span) * w
                        val y = h * (1f - value / 100f)
                        if (!pen) { path.moveTo(x, y); pen = true } else path.lineTo(x, y)
                    }
                    drawPath(path, col, style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round))
                }
                plot(1, cL)
                plot(2, cR)
            }
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Tx("Left", 12, cL, FontWeight.SemiBold)
                Tx("Right", 12, cR, FontWeight.SemiBold)
                Spacer(Modifier.width(4.dp))
                Tx("Last 12 hours", 12, P.mute, FontWeight.Normal)
            }
        }
    }
}
