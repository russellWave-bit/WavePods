package com.breadwinner.wavepods

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.abs

fun btPerms(): Array<String> {
    val l = ArrayList<String>()
    if (Build.VERSION.SDK_INT >= 31) {
        l.add(Manifest.permission.BLUETOOTH_SCAN)
        l.add(Manifest.permission.BLUETOOTH_CONNECT)
    }
    l.add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    return l.toTypedArray()
}

fun btOn(c: Context): Boolean =
    try { (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true } catch (e: Exception) { false }

@Composable
fun WavePodsApp() {
    var tab by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(P.bg)) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> PodsPage()
                1 -> FindPage()
                else -> SettingsPage()
            }
        }
        BottomBar(tab) { tab = it }
    }
}

@Composable
fun PodsPage() {
    val ctx = LocalContext.current
    var bump by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bump++
        PodsService.start(ctx)
    }
    val enable = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        bump++
        PodsService.rescan()
    }
    val perms = remember(bump, Pods.tick) { PodsService.hasPerms(ctx) }
    val bt = remember(bump, Pods.tick) { btOn(ctx) }
    val r = Pods.reading
    val ok = Pods.fresh()
    // reading Pods.tick makes this screen refresh every few seconds
    val age = if (r != null) ((System.currentTimeMillis() - r.at) / 1000L).toInt() + (if (Pods.tick < 0) 1 else 0) else 0

    Page {
        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Tx("WavePods", 26, weight = FontWeight.Bold)
                Tx(if (ok && r != null) r.model else Pods.status, 13, P.mute, FontWeight.Normal)
            }
            Chip(if (Pods.running) "Scanning" else "Stopped", if (Pods.running) P.green else P.mute)
        }

        if (!perms) Banner("WavePods needs permission to look for nearby Bluetooth devices.", P.amber, "Allow") { launcher.launch(btPerms()) }
        else if (!bt) Banner("Bluetooth is off.", P.amber, "Turn on") { enable.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
        else if (!Pods.running) Banner("The scanner isn't running.", P.amber, "Start") { Prefs.put("run", true); PodsService.start(ctx) }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            PodCard("Left", if (ok) r?.left else null, Modifier.weight(1f))
            PodCard("Right", if (ok) r?.right else null, Modifier.weight(1f))
        }

        val cp = if (ok) r?.casePct else null
        val caseFg = if (cp != null) P.ink else P.text
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(if (cp != null) P.lilac else P.card).padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Tx("Case", 15, caseFg, FontWeight.Bold)
                Tx(if (cp != null) "$cp%" else "Not reporting", if (cp != null) 34 else 18, caseFg, FontWeight.Bold, family = if (cp != null) Cond else null)
            }
            if (ok && r != null && r.caseCharging) ChipSolid("Charging", P.ink, Color.White)
        }

        if (ok && r != null) {
            val l = r.left.pct
            val rr = r.right.pct
            if (l != null && rr != null && abs(l - rr) >= 30) {
                val lower = if (l < rr) "Left" else "Right"
                Banner("$lower is much lower than the other pod. That can mean it is older, worn, or was used more.", P.amber)
            }
            Tx("Updated " + (if (age < 3) "just now" else "$age s ago"), 12, P.mute, FontWeight.Normal)
        } else if (r != null) {
            Tx("Pods not heard for a while. Open the case lid or put a bud in your ear.", 12, P.mute, FontWeight.Normal)
        }

        val s = Pods.single
        if (!ok && s != null) {
            Card {
                Tx("Connected: " + s.first, 14)
                Tx("This pair shares one battery number only.", 12, P.mute, FontWeight.Normal)
                Spacer(Modifier.height(8.dp))
                Tx(s.second.toString() + "%", 44, lvl(s.second), FontWeight.Bold, family = Cond)
                Meter(s.second)
            }
        }

        Card {
            Tx("Left and right the wrong way round?", 14)
            Tx("Some copies label the buds the other way. Tap swap to fix it.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Btn("Swap left and right") { Prefs.put("swap", !Prefs.b("swap", false)); Pods.clear() }
                if (Pods.running) Btn("Stop scanning") { PodsService.stop(ctx) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun PodCard(label: String, s: Side?, modifier: Modifier) {
    val p = s?.pct
    val block = if (p != null) lvl(p) else P.card
    val fg = if (p != null) P.ink else P.text
    Column(modifier.clip(RoundedCornerShape(28.dp)).background(block).padding(18.dp)) {
        Tx(label, 16, fg, FontWeight.Bold)
        Row(verticalAlignment = Alignment.Bottom) {
            Tx(if (p != null) "$p" else "--", 76, fg, FontWeight.Bold, family = Cond)
            if (p != null) Tx("%", 26, fg, FontWeight.Bold, modifier = Modifier.padding(start = 2.dp, bottom = 14.dp))
        }
        Spacer(Modifier.height(6.dp))
        Meter(p, onBlock = p != null)
        Spacer(Modifier.height(14.dp))
        when {
            s == null -> ChipSolid("No signal", P.track, P.mute)
            p == null -> ChipSolid("Off or in case", P.track, P.mute)
            s.charging -> ChipSolid("Charging", P.ink, Color.White)
            s.inEar -> ChipSolid("In ear", P.ink, Color.White)
            else -> ChipSolid("Out of ear", P.ink, Color.White)
        }
    }
}

@Composable
fun FindPage() {
    val r = Pods.reading
    val ok = Pods.fresh()
    val v = Pods.rssiSmooth
    val f = if (!ok) 0f else ((v + 100) / 60f).coerceIn(0f, 1f)
    val word = when {
        !ok -> "No signal"
        v >= -52 -> "Very close"
        v >= -64 -> "Close"
        v >= -76 -> "In the room"
        v >= -88 -> "Far"
        else -> "Very far"
    }
    Page {
        Tx("Find my pods", 26, weight = FontWeight.Bold)
        Tx("Walk around. The bar fills as you get closer.", 13, P.mute, FontWeight.Normal)
        Card {
            Tx(word, 40, if (ok) P.green else P.mute, FontWeight.Bold, family = Cond)
            Spacer(Modifier.height(10.dp))
            Meter((f * 100).toInt())
            Spacer(Modifier.height(8.dp))
            if (ok && r != null) Tx("Signal " + r.rssi + " dBm", 12, P.mute, FontWeight.Normal)
        }
        Card {
            Tx("What I can hear", 15, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Tx("Apple-style broadcasts: " + Pods.dbgApple, 13, P.mute, FontWeight.Normal)
            Tx("Pods broadcasts: " + Pods.dbgPods, 13, P.mute, FontWeight.Normal)
            if (Pods.dbgTypes.isNotEmpty()) Tx(Pods.dbgTypes, 12, P.mute, FontWeight.Normal)
            if (Pods.dbgHex.isNotEmpty()) Tx(Pods.dbgHex, 11, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(4.dp))
            Tx("Open the case lid next to the phone, then look here. If both numbers stay at 0, your pods aren't broadcasting.", 12, P.mute, FontWeight.Normal)
        }
        Card {
            Tx("Good to know", 15, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Tx("Pods only send a signal when they are awake: lid open, or a bud out of the case. A closed case in a drawer stays silent.", 13, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(6.dp))
            Tx("Walls and bodies weaken the signal, so check a few spots.", 13, P.mute, FontWeight.Normal)
        }
    }
}

@Composable
fun SettingsPage() {
    val ctx = LocalContext.current
    Page {
        Tx("Settings", 26, weight = FontWeight.Bold)
        Card {
            Tx("Look", 15, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Seg(listOf("Dark", "Light"), if (Prefs.s("theme", "dark") == "dark") 0 else 1) { Prefs.put("theme", if (it == 0) "dark" else "light") }
        }
        Card {
            Tx("Alerts", 15, weight = FontWeight.SemiBold)
            ToggleRow("Low battery alert", "A notification for each bud on its own", Prefs.b("alerts", true)) { Prefs.put("alerts", it) }
            SliderRow("Warn me at", Prefs.i("low", 20).toFloat(), 10f..50f, Prefs.i("low", 20).toString() + "%") { Prefs.put("low", (it / 10f).toInt() * 10) }
            ToggleRow("Pop-up when pods appear", "Shows both batteries when you open the case", Prefs.b("popup", true)) { Prefs.put("popup", it) }
        }
        Card {
            Tx("How far to listen", 15, weight = FontWeight.SemiBold)
            Tx("Stops you picking up someone else's pods.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            val rs = listOf("near", "room", "far")
            Seg(listOf("Near me", "This room", "Far"), rs.indexOf(Prefs.s("range", "room")).coerceAtLeast(0)) { Prefs.put("range", rs[it]); Pods.clear() }
            Spacer(Modifier.height(14.dp))
            Tx("Scanning speed", 14)
            Spacer(Modifier.height(6.dp))
            Seg(listOf("Battery saver", "Fast"), if (Prefs.s("scan", "saver") == "fast") 1 else 0) {
                Prefs.put("scan", if (it == 1) "fast" else "saver")
                PodsService.rescan()
            }
        }
        Card {
            Tx("Left and right", 15, weight = FontWeight.SemiBold)
            ToggleRow("Swap left and right", "Turn on if your copy shows them the wrong way round", Prefs.b("swap", false)) { Prefs.put("swap", it); Pods.clear() }
        }
        Card {
            Tx("Keep it running", 15, weight = FontWeight.SemiBold)
            Tx("So Android doesn't stop the scanner, set WavePods battery to Unrestricted.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            Btn("Battery settings") {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) { }
                }
            }
        }
        Card {
            Tx("About", 15, weight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Tx("WavePods listens to the battery broadcast that AirPods and most AirPods copies send. Readings come in steps of 10%. Pairs that don't send it show one number if the phone knows it. Nothing leaves your phone.", 12, P.mute, FontWeight.Normal)
        }
        Spacer(Modifier.height(8.dp))
    }
}
