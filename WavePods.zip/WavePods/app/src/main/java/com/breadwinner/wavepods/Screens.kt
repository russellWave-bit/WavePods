package com.breadwinner.wavepods

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import kotlin.math.abs

fun btPerms(): Array<String> {
    val l = ArrayList<String>()
    if (Build.VERSION.SDK_INT >= 31) {
        l.add(Manifest.permission.BLUETOOTH_SCAN)
        l.add(Manifest.permission.BLUETOOTH_CONNECT)
    }
    l.add(Manifest.permission.ACCESS_FINE_LOCATION)
    if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
    return l.toTypedArray()
}

fun btOn(c: Context): Boolean =
    try { (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter?.isEnabled == true } catch (e: Exception) { false }

@Composable
fun WavePodsApp() {
    var tab by remember { mutableIntStateOf(0) }
    val view = LocalView.current
    SideEffect {
        val act = view.context as? Activity
        if (act != null) {
            val ctl = WindowCompat.getInsetsController(act.window, view)
            ctl.isAppearanceLightStatusBars = !P.pro
            ctl.isAppearanceLightNavigationBars = !P.pro
        }
    }
    Column(Modifier.fillMaxSize().background(P.bg)) {
        Box(Modifier.weight(1f)) {
            when (tab) {
                0 -> PodsPage()
                1 -> ShopPage { tab = 0 }
                2 -> FindPage()
                else -> SettingsPage()
            }
        }
        BottomBar(tab) { tab = it }
    }
}

// ---------------------------------------------------------------- Pods

@Composable
fun PodsPage() {
    val ctx = LocalContext.current
    var bump by remember { mutableIntStateOf(0) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        bump++
        PodsService.start(ctx)
    }
    val enable = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        bump++
        PodsService.rescan()
    }
    val perms = remember(bump, Pods.tick) { PodsService.hasPerms(ctx) }
    val bt = remember(bump, Pods.tick) { btOn(ctx) }
    val r = Pods.reading
    val ok = Pods.fresh()
    val age = if (r != null) ((System.currentTimeMillis() - r.at) / 1000L).toInt() + (if (Pods.tick < 0L) 1 else 0) else 0
    var naming by remember { mutableStateOf(false) }
    var nameText by remember { mutableStateOf("") }
    val active = Saved.active()

    Page {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Tx("WavePods", 28, P.text, FontWeight.Bold)
                Tx(
                    if (active != null) "Tracking " + active.name else if (ok && r != null) r.model else Pods.status,
                    13, P.mute, FontWeight.Normal
                )
            }
            StatusLine(if (Pods.running) "Scanning" else "Stopped", if (Pods.running) P.good else P.mute)
        }

        if (!perms) Banner("WavePods needs permission to look for nearby Bluetooth devices.", P.mid, "Allow") { launcher.launch(btPerms()) }
        else if (!bt) Banner("Bluetooth is off.", P.mid, "Turn on") { enable.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)) }
        else if (!Pods.running) Banner("The scanner isn't running.", P.mid, "Start") { Prefs.put("run", true); PodsService.start(ctx) }

        if (ok && Pods.nearby >= 2 && active == null) {
            Banner(Pods.nearby.toString() + " sets of pods are nearby. I'm showing the closest. Hold yours next to the phone, or pick yours in Shop.", P.mid)
        }

        Panel(pad = 0.dp) {
            Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
                PodColumn("Left", if (ok) r?.left else null, Modifier.weight(1f))
                Box(Modifier.width(1.dp).fillMaxHeight().background(P.line))
                PodColumn("Right", if (ok) r?.right else null, Modifier.weight(1f))
            }
            HLine()
            CaseRow(if (ok) r else null)
        }

        if (ok && r != null) {
            val l = r.left.pct
            val rr = r.right.pct
            if (l != null && rr != null && abs(l - rr) >= 30) {
                Banner((if (l < rr) "Left" else "Right") + " is much lower than the other pod. It may be older, worn, or used more.", P.mid)
            }
            Tx("Updated " + (if (age < 3) "just now" else "$age s ago"), 12, P.mute, FontWeight.Normal)
        } else if (r != null) {
            Tx("Pods not heard for a while. Open the case lid or put a bud in your ear.", 12, P.mute, FontWeight.Normal)
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Btn("Save pods", Modifier.weight(1f), enabled = ok && r != null) { naming = !naming }
            Btn("Report", Modifier.weight(1f), enabled = ok && r != null) { if (r != null) Report.share(ctx, r) }
            Btn("Swap L/R", Modifier.weight(1f)) { Prefs.put("swap", !Prefs.b("swap", false)); Pods.clear() }
        }

        if (naming && r != null) {
            Panel {
                Tx("Name these pods", 15, P.text, FontWeight.SemiBold)
                Tx("WavePods will track only this model and colour from now on.", 12, P.mute, FontWeight.Normal)
                Spacer(Modifier.height(10.dp))
                TextBox(nameText, "e.g. My pods") { nameText = it }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Btn("Save", primary = true, enabled = nameText.isNotBlank()) {
                        Saved.add(nameText, r.code, r.color)
                        naming = false
                        nameText = ""
                        Pods.clear()
                    }
                    Btn("Cancel") { naming = false }
                }
            }
        }

        val s = Pods.single
        if (!ok && s != null) {
            Panel {
                Tx("Connected: " + s.first, 14, P.text, FontWeight.SemiBold)
                Tx("This pair shares one battery number only.", 12, P.mute, FontWeight.Normal)
                Spacer(Modifier.height(8.dp))
                Tx(s.second.toString() + "%", 44, lvl(s.second), FontWeight.Bold, family = Cond)
                Spacer(Modifier.height(6.dp))
                Ticks(s.second)
            }
        }

        HistoryPanel()

        Btn(if (Pods.running) "Stop scanning" else "Start scanning", Modifier.fillMaxWidth()) {
            if (Pods.running) PodsService.stop(ctx) else { Prefs.put("run", true); PodsService.start(ctx) }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun PodColumn(label: String, s: Side?, modifier: Modifier) {
    val p = s?.pct
    Column(modifier.padding(18.dp)) {
        Tx(label, 14, P.mute, FontWeight.Medium)
        Row(verticalAlignment = Alignment.Bottom) {
            Tx(if (p != null) "$p" else "--", 84, if (p != null) lvl(p) else P.mute, FontWeight.Bold, family = Cond)
            if (p != null) Tx("%", 22, P.mute, FontWeight.Medium, Modifier.padding(start = 2.dp, bottom = 16.dp))
        }
        Ticks(p)
        Spacer(Modifier.height(12.dp))
        when {
            s == null -> StatusLine("No signal", P.mute)
            p == null -> StatusLine("Off or in case", P.mute)
            s.charging -> StatusLine("Charging", P.good)
            s.inEar -> StatusLine("In ear", P.text)
            else -> StatusLine("Out of ear", P.mid)
        }
    }
}

@Composable
fun CaseRow(r: Reading?) {
    val cp = r?.casePct
    Row(Modifier.fillMaxWidth().padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx("Case", 14, P.mute, FontWeight.Medium)
            Tx(
                if (cp != null) "$cp%" else "Not reporting", if (cp != null) 36 else 16,
                if (cp != null) lvl(cp) else P.mute, FontWeight.Bold, family = if (cp != null) Cond else null
            )
        }
        Column(Modifier.width(130.dp), horizontalAlignment = Alignment.End) {
            Ticks(cp, h = 14.dp)
            if (r != null && r.caseCharging) {
                Spacer(Modifier.height(8.dp))
                StatusLine("Charging", P.good)
            }
        }
    }
}

// ---------------------------------------------------------------- Shop

@Composable
fun ShopPage(go: () -> Unit) {
    val rows = Pods.shop
    Page {
        Tx("Shop mode", 28, P.text, FontWeight.Bold)
        Tx("Every set of pods in range, closest first. Tap one to track it.", 13, P.mute, FontWeight.Normal)
        if (rows.isEmpty()) {
            Panel {
                Tx("Nothing heard yet.", 14, P.text, FontWeight.SemiBold)
                Tx("Open a case lid or take a bud out near the phone. Each awake set shows up here.", 12, P.mute, FontWeight.Normal)
            }
        } else {
            Tx(rows.size.toString() + (if (rows.size == 1) " set" else " sets") + " heard", 12, P.mute, FontWeight.Medium)
            Panel(pad = 0.dp) {
                rows.forEachIndexed { i, r ->
                    if (i > 0) HLine()
                    ShopRow(r, Pods.lockAddr == r.addr) { Pods.lockTo(r.addr); go() }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun ShopRow(r: Reading, tracked: Boolean, onTrack: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onTrack).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Tx(r.model, 14, P.text, FontWeight.SemiBold, maxLines = 1)
            Tx(
                distWord(r.rssi) + "  ·  " + r.rssi + " dBm" + (if (tracked) "  ·  Tracking" else ""),
                12, if (tracked) P.accent else P.mute, FontWeight.Normal
            )
        }
        MiniNum("L", r.left.pct)
        MiniNum("R", r.right.pct)
        MiniNum("C", r.casePct)
    }
}

@Composable
fun MiniNum(label: String, p: Int?) {
    Column(Modifier.width(48.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Tx(label, 10, P.mute, FontWeight.Medium)
        Tx(if (p != null) "$p" else "--", 22, lvl(p), FontWeight.Bold, family = Cond)
    }
}

// ---------------------------------------------------------------- Settings

@Composable
fun LookOption(
    title: String, sub: String, key: String,
    bg: Color, surface: Color, accent: Color, good: Color, modifier: Modifier
) {
    val sel = Prefs.s("look", "graphite") == key
    val shape = RoundedCornerShape(8.dp)
    Column(
        modifier.clip(shape).border(if (sel) 2.dp else 1.dp, if (sel) P.accent else P.line, shape)
            .clickable { Prefs.put("look", key) }.padding(10.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(4.dp)).background(bg).padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(Modifier.weight(1f).fillMaxHeight().background(surface))
            Box(Modifier.weight(1f).fillMaxHeight().background(accent))
            Box(Modifier.weight(1f).fillMaxHeight().background(good))
        }
        Spacer(Modifier.height(8.dp))
        Tx(title, 14, P.text, FontWeight.SemiBold)
        Tx(sub, 11, P.mute, FontWeight.Normal)
    }
}

@Composable
fun SettingsPage() {
    val ctx = LocalContext.current
    Page {
        Tx("Settings", 28, P.text, FontWeight.Bold)

        Panel {
            Tx("Look", 15, P.text, FontWeight.SemiBold)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                LookOption(
                    "Graphite", "Charcoal and amber", "graphite",
                    Color(0xFF121315), Color(0xFF1B1D20), Color(0xFFFF9F1C), Color(0xFF4CD97B), Modifier.weight(1f)
                )
                LookOption(
                    "Bone", "Paper and ink", "bone",
                    Color(0xFFEBE8E1), Color(0xFFF7F5F0), Color(0xFF141414), Color(0xFF1E9E5A), Modifier.weight(1f)
                )
            }
        }

        Panel {
            Tx("My pods", 15, P.text, FontWeight.SemiBold)
            Tx("Matched by model and colour. Two identical pairs nearby can still mix, so keep yours close.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            val saved = Saved.all()
            val track = Prefs.s("track", "")
            if (saved.isEmpty()) Tx("None saved. On the Pods tab, tap Save pods.", 13, P.mute, FontWeight.Normal)
            for (sv in saved) {
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Tx(sv.name, 14, P.text, FontWeight.SemiBold)
                        Tx(Decode.modelName(sv.code), 12, P.mute, FontWeight.Normal)
                    }
                    Btn(if (track == sv.name) "Tracking" else "Track", primary = track == sv.name) {
                        Prefs.put("track", if (track == sv.name) "" else sv.name)
                        Pods.clear()
                    }
                    Spacer(Modifier.width(6.dp))
                    Btn("Delete") { Saved.remove(sv.name); Pods.clear() }
                }
            }
            if (track.isNotEmpty()) {
                Spacer(Modifier.height(6.dp))
                Btn("Track the nearest pods again") { Prefs.put("track", ""); Pods.clear() }
            }
        }

        Panel {
            Tx("Alerts", 15, P.text, FontWeight.SemiBold)
            ToggleRow("Low battery alert", "A notification for each bud on its own", Prefs.b("alerts", true)) { Prefs.put("alerts", it) }
            SliderRow("Warn me at", Prefs.i("low", 20).toFloat(), 10f..50f, Prefs.i("low", 20).toString() + "%") { Prefs.put("low", (it / 10f).toInt() * 10) }
            ToggleRow("Charged alert", "Tells you when both buds reach 100%", Prefs.b("charged", true)) { Prefs.put("charged", it) }
            ToggleRow("Pop-up when pods appear", "Shows both batteries when you open the case", Prefs.b("popup", true)) { Prefs.put("popup", it) }
        }

        Panel {
            Tx("Listening", 15, P.text, FontWeight.SemiBold)
            Tx("How far to listen stops you picking up someone else's pods.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            val rs = listOf("near", "room", "far")
            Seg(listOf("Near me", "This room", "Far"), rs.indexOf(Prefs.s("range", "near")).coerceAtLeast(0)) { Prefs.put("range", rs[it]); Pods.clear() }
            Spacer(Modifier.height(14.dp))
            Tx("Scanning speed", 14, P.text)
            Spacer(Modifier.height(6.dp))
            Seg(listOf("Battery saver", "Fast"), if (Prefs.s("scan", "saver") == "fast") 1 else 0) {
                Prefs.put("scan", if (it == 1) "fast" else "saver")
                PodsService.rescan()
            }
            ToggleRow("Swap left and right", "Turn on if your copy shows them the wrong way round", Prefs.b("swap", false)) { Prefs.put("swap", it); Pods.clear() }
        }

        Panel {
            Tx("Find", 15, P.text, FontWeight.SemiBold)
            ToggleRow("Buzz when very close", "A short vibration on the Find screen", Prefs.b("buzz", true)) { Prefs.put("buzz", it) }
        }

        Panel {
            Tx("Pair report", 15, P.text, FontWeight.SemiBold)
            Tx("Your shop name is printed at the top of the report picture.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            TextBox(Prefs.s("shop", ""), "Shop name") { Prefs.put("shop", it) }
        }

        Panel {
            Tx("Keep it running", 15, P.text, FontWeight.SemiBold)
            ToggleRow("Start with the phone", "Starts scanning after a restart", Prefs.b("boot", true)) { Prefs.put("boot", it) }
            Tx("So Android doesn't stop the scanner, set WavePods battery to Unrestricted.", 12, P.mute, FontWeight.Normal)
            Spacer(Modifier.height(8.dp))
            Btn("Battery settings") {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + ctx.packageName))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (e: Exception) {
                    try { ctx.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e2: Exception) { }
                }
            }
        }

        Panel {
            Tx("About", 15, P.text, FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Tx("WavePods listens to the battery broadcast that AirPods and most AirPods copies send. Readings come in steps of 10%. Pairs that don't send it show one number if the phone knows it. Nothing leaves your phone.", 12, P.mute, FontWeight.Normal)
        }
        Spacer(Modifier.height(8.dp))
    }
}
