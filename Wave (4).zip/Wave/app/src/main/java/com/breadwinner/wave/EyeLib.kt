package com.breadwinner.wave

import android.graphics.BlendMode
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin

private const val TAU = 6.2831855f
private const val PI_F = 3.1415927f

/** Same pseudo-random numbers as the Eye Lab, so the eyes look the same here. */
private fun rnd(i: Number): Float {
    val x = sin(i.toDouble() * 127.1 + 311.7) * 43758.5453
    return (x - floor(x)).toFloat()
}

private fun noise(x: Float): Float = sin(x) * 0.5f + sin(x * 2.3f + 1.7f) * 0.3f + sin(x * 4.1f + 0.4f) * 0.2f

/** CSS-style hsl colour. h 0..360, s and l 0..100, a 0..1. */
fun hsl(h: Float, s: Float, l: Float, a: Float): Int {
    val hh = ((h % 360f) + 360f) % 360f
    val ss = (s / 100f).coerceIn(0f, 1f)
    val ll = (l / 100f).coerceIn(0f, 1f)
    val aa = ss * min(ll, 1f - ll)
    fun f(n: Float): Float {
        val k = (n + hh / 30f) % 12f
        return ll - aa * max(-1f, min(min(k - 3f, 9f - k), 1f))
    }
    return Color.argb(
        (a * 255f).toInt().coerceIn(0, 255),
        (f(0f) * 255f).toInt().coerceIn(0, 255),
        (f(8f) * 255f).toInt().coerceIn(0, 255),
        (f(4f) * 255f).toInt().coerceIn(0, 255)
    )
}

/** The eye library: every eye is a small recipe the sphere engine draws. Mirrors the Eye Lab. */
object EyeLib {
    class Spec(
        val abs: Float? = null,
        val dh: Float = 0f,
        val sat: Float = 90f,
        val lum: Float = 1f,
        val iris: String = "fibre",
        val shape: String = "round",
        val ir: Float = 0.52f,
        val pupil: Float = 0.36f,
        val open: Float = 1f,
        val sclera: String = "white",
        val veins: Boolean = false,
        val lid: String = "auto",
        val hl: String = "window",
        val aura: String = "none",
        val seed: Int = 3,
        val limbal: Float = 0.6f
    )

    class Entry(val id: String, val name: String, val cat: String, val spec: Spec)

    val cats = listOf(
        "jarvis" to "Jarvis", "real" to "Real", "beast" to "Creatures", "tech" to "Tech",
        "magic" to "Magic", "anime" to "Anime"
    )

    val all: List<Entry> = listOf(
        // real
        Entry("human_blue", "Blue", "real", Spec(abs = 205f, sat = 70f, iris = "fibre", veins = true, open = 0.66f, lid = "soft", seed = 3)),
        Entry("human_green", "Green", "real", Spec(abs = 125f, sat = 55f, iris = "fibre", veins = true, open = 0.66f, lid = "soft", seed = 7)),
        Entry("human_brown", "Brown", "real", Spec(abs = 27f, sat = 65f, lum = 0.85f, iris = "fibre", veins = true, open = 0.66f, lid = "soft", seed = 11, pupil = 0.32f)),
        Entry("hazel", "Hazel", "real", Spec(abs = 48f, sat = 70f, iris = "fibre", veins = true, open = 0.66f, lid = "soft", seed = 5)),
        Entry("storm", "Storm grey", "real", Spec(abs = 212f, sat = 14f, lum = 1.15f, iris = "fibre", veins = true, open = 0.66f, lid = "soft", seed = 9)),
        Entry("wolf", "Wolf", "real", Spec(abs = 40f, sat = 100f, iris = "fibre", open = 0.56f, lid = "soft", seed = 2, pupil = 0.3f)),
        Entry("ball", "Floating ball", "real", Spec(abs = 200f, sat = 75f, iris = "fibre", veins = true, open = 1f, lid = "none", seed = 4)),
        // creatures
        Entry("cat", "Cat", "beast", Spec(abs = 78f, sat = 95f, iris = "fibre", shape = "slit", ir = 0.8f, open = 0.7f, sclera = "black", lid = "soft", seed = 6, limbal = 0.5f)),
        Entry("dragon", "Dragon", "beast", Spec(abs = 16f, sat = 100f, iris = "fire", shape = "slit", ir = 0.78f, open = 0.72f, sclera = "dark", aura = "flame", lid = "soft")),
        Entry("goat", "Goat", "beast", Spec(abs = 46f, sat = 80f, iris = "fibre", shape = "hslit", ir = 0.74f, open = 0.62f, sclera = "black", lid = "soft", seed = 8)),
        Entry("snake", "Viper", "beast", Spec(abs = 95f, sat = 95f, iris = "fibre", shape = "slit", ir = 0.82f, open = 0.6f, sclera = "black", lid = "soft", seed = 12)),
        Entry("owl", "Owl", "beast", Spec(abs = 36f, sat = 100f, iris = "fibre", ir = 0.8f, pupil = 0.5f, open = 1f, sclera = "dark", lid = "none", seed = 14)),
        Entry("alien", "Alien", "beast", Spec(abs = 150f, sat = 80f, iris = "galaxy", shape = "none", ir = 0.92f, open = 0.56f, sclera = "black", lid = "soft")),
        // tech
        Entry("lens", "Camera lens", "tech", Spec(abs = 190f, sat = 90f, iris = "aperture", ir = 0.62f, pupil = 0.3f, open = 1f, sclera = "dark", aura = "orbit", lid = "none")),
        Entry("circuit", "Circuit", "tech", Spec(abs = 150f, sat = 90f, iris = "circuit", ir = 0.62f, open = 1f, sclera = "dark", aura = "orbit", lid = "none")),
        Entry("sentinel", "Red sentinel", "tech", Spec(abs = 0f, sat = 100f, iris = "aperture", ir = 0.66f, pupil = 0.28f, open = 1f, sclera = "black", lid = "none", hl = "none")),
        Entry("holo", "Hologram", "tech", Spec(abs = 190f, sat = 90f, iris = "rings", ir = 0.62f, pupil = 0.24f, open = 1f, sclera = "glow", aura = "orbit", lid = "none")),
        Entry("scanner", "Scanner", "tech", Spec(abs = 170f, sat = 95f, iris = "rings", shape = "none", ir = 0.7f, open = 1f, sclera = "dark", aura = "halo", lid = "none", hl = "none")),
        // magic
        Entry("fire", "Fire", "magic", Spec(abs = 14f, sat = 100f, iris = "fire", ir = 0.7f, open = 1f, sclera = "dark", aura = "flame", lid = "none")),
        Entry("ice", "Ice", "magic", Spec(abs = 195f, sat = 90f, lum = 1.15f, iris = "fibre", ir = 0.6f, open = 0.8f, sclera = "white", aura = "sparkles", lid = "soft", seed = 15)),
        Entry("storm2", "Lightning", "magic", Spec(abs = 55f, sat = 100f, iris = "circuit", ir = 0.6f, open = 1f, sclera = "dark", aura = "orbit", lid = "none")),
        Entry("void", "Void", "magic", Spec(abs = 270f, sat = 85f, iris = "galaxy", ir = 0.72f, open = 1f, sclera = "black", aura = "orbit", lid = "none")),
        Entry("nature", "Forest", "magic", Spec(abs = 112f, sat = 70f, iris = "flower", ir = 0.62f, open = 0.85f, sclera = "white", aura = "sparkles", lid = "soft", seed = 16)),
        Entry("gold", "Gold", "magic", Spec(abs = 45f, sat = 100f, lum = 1.2f, iris = "rings", ir = 0.62f, open = 1f, sclera = "dark", aura = "halo", lid = "none")),
        Entry("ghost", "Ghost", "magic", Spec(abs = 185f, sat = 40f, iris = "plain", shape = "none", ir = 0.5f, open = 0.8f, sclera = "glow", lid = "soft", hl = "none")),
        Entry("demon", "Demon", "magic", Spec(abs = 48f, sat = 100f, iris = "fibre", shape = "slit", ir = 0.62f, open = 0.7f, sclera = "red", lid = "soft", seed = 20)),
        Entry("angel", "Angel", "magic", Spec(abs = 200f, sat = 70f, iris = "fibre", ir = 0.56f, open = 0.74f, sclera = "white", aura = "halo", lid = "soft", seed = 21)),
        // anime (all original designs)
        Entry("an_girl", "Glossy (pink)", "anime", Spec(abs = 330f, sat = 85f, iris = "anime", ir = 0.62f, pupil = 0.34f, open = 0.92f, lid = "lash", hl = "round")),
        Entry("an_boy", "Glossy (blue)", "anime", Spec(abs = 205f, sat = 90f, iris = "anime", ir = 0.62f, pupil = 0.34f, open = 0.9f, lid = "thick", hl = "round")),
        Entry("an_sparkle", "Sparkle", "anime", Spec(abs = 280f, sat = 85f, iris = "anime", ir = 0.64f, pupil = 0.3f, open = 0.92f, lid = "lash", hl = "sparkle", aura = "sparkles")),
        Entry("an_star", "Star pupil", "anime", Spec(abs = 48f, sat = 100f, iris = "anime", shape = "star", ir = 0.62f, pupil = 0.4f, open = 0.92f, lid = "thick", hl = "sparkle", aura = "sparkles")),
        Entry("an_heart", "Heart", "anime", Spec(abs = 340f, sat = 90f, iris = "anime", shape = "heart", ir = 0.62f, pupil = 0.42f, open = 0.92f, lid = "lash", hl = "round", aura = "sparkles")),
        Entry("an_cross", "Cross", "anime", Spec(abs = 185f, sat = 90f, iris = "anime", shape = "cross", ir = 0.62f, pupil = 0.42f, open = 0.92f, lid = "thick", hl = "round")),
        Entry("an_spiral", "Swirl", "anime", Spec(abs = 300f, sat = 90f, iris = "swirl", ir = 0.62f, pupil = 0.2f, open = 0.92f, lid = "thick", hl = "round")),
        Entry("an_flower", "Blossom", "anime", Spec(abs = 330f, sat = 85f, iris = "flower", ir = 0.62f, pupil = 0.24f, open = 0.92f, lid = "lash", hl = "round", aura = "sparkles")),
        Entry("an_galaxy", "Starry night", "anime", Spec(abs = 250f, sat = 90f, iris = "galaxy", ir = 0.66f, pupil = 0.26f, open = 0.92f, lid = "lash", hl = "sparkle")),
        Entry("an_sleepy", "Sleepy", "anime", Spec(abs = 215f, sat = 70f, iris = "anime", ir = 0.62f, pupil = 0.3f, open = 0.5f, lid = "thick", hl = "round")),
        Entry("an_fierce", "Fierce", "anime", Spec(abs = 0f, sat = 95f, iris = "anime", shape = "slit", ir = 0.62f, pupil = 0.3f, open = 0.5f, lid = "thick", hl = "round")),
        Entry("an_dream", "Dreamy", "anime", Spec(abs = 175f, sat = 80f, iris = "anime", ir = 0.64f, pupil = 0.28f, open = 0.88f, lid = "lash", hl = "sparkle", aura = "sparkles")),
        Entry("an_key", "Keyhole", "anime", Spec(abs = 320f, sat = 90f, iris = "anime", shape = "keyhole", ir = 0.62f, pupil = 0.4f, open = 0.92f, lid = "thick", hl = "round")),
        Entry("an_diamond", "Diamond", "anime", Spec(abs = 150f, sat = 90f, iris = "anime", shape = "diamond", ir = 0.62f, pupil = 0.4f, open = 0.92f, lid = "thick", hl = "round")),
        Entry("an_dark", "Moonless", "anime", Spec(abs = 275f, sat = 90f, iris = "rings", ir = 0.64f, pupil = 0.2f, open = 0.9f, sclera = "dark", lid = "thick", hl = "round", aura = "orbit"))
    )

    private val byId = all.associateBy { it.id }
    fun find(id: String): Entry? = byId[id]
}

/** Draws one library eye as a shaded little sphere. */
class EyeSphere {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val lensP = Path()
    private val rf = RectF()
    private var hue = 200f
    private var sat = 90f
    private var lumK = 1f
    private var u = 1f

    private fun col(l: Float, a: Float, dh: Float = 0f, s: Float = sat): Int = hsl(hue + dh, s, (l * lumK).coerceIn(0f, 100f), a)
    private fun add(on: Boolean) { p.blendMode = if (on) BlendMode.PLUS else BlendMode.SRC_OVER }
    private fun stroke(w: Float, color: Int) { p.style = Paint.Style.STROKE; p.strokeWidth = w * u; p.color = color; p.shader = null }
    private fun fill(color: Int) { p.style = Paint.Style.FILL; p.color = color; p.shader = null }
    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float) { c.drawLine(x1, y1, x2, y2, p) }
    private fun oval(c: Canvas, x: Float, y: Float, rx: Float, ry: Float) { rf.set(x - rx, y - ry, x + rx, y + ry); c.drawOval(rf, p) }
    private fun star4(c: Canvas, x: Float, y: Float, s: Float) {
        path.reset()
        path.moveTo(x, y - s * 2.6f); path.lineTo(x + s * 0.5f, y - s * 0.5f); path.lineTo(x + s * 2.6f, y); path.lineTo(x + s * 0.5f, y + s * 0.5f)
        path.lineTo(x, y + s * 2.6f); path.lineTo(x - s * 0.5f, y + s * 0.5f); path.lineTo(x - s * 2.6f, y); path.lineTo(x - s * 0.5f, y - s * 0.5f)
        path.close(); c.drawPath(path, p)
    }

    /** A soft glow made of a few wider, fainter strokes (hardware canvases can't blur shapes). */
    private fun glowStroke(c: Canvas, w: Float, color: Int, k: Float, draw: () -> Unit) {
        for (i in 3 downTo 1) {
            p.style = Paint.Style.STROKE; p.shader = null
            p.strokeWidth = (w + i * 4.5f) * u
            p.color = (color and 0x00FFFFFF) or ((((color ushr 24) and 0xFF) * 0.12f * k).toInt().coerceIn(0, 255) shl 24)
            draw()
        }
        p.strokeWidth = w * u; p.color = color
        draw()
    }

    /** st: 0 waiting, 1 listening, 2 thinking, 3 speaking. */
    fun draw(
        c: Canvas, sp: EyeLib.Spec, cx: Float, cy: Float, rb: Float, t: Float, spin: Float,
        gxIn: Float, gyIn: Float, st: Int, lv: Float, blink: Float, wander: Boolean, userHue: Float, own: Boolean, glowK: Float
    ) {
        hue = if (own) userHue + sp.dh else (sp.abs ?: (userHue + sp.dh))
        sat = sp.sat
        lumK = sp.lum
        u = rb / 140f
        val listening = st == 1
        val thinking = st == 2
        val speaking = st == 3
        var gx = gxIn
        var gy = gyIn
        if (thinking) { val q = floor(t * 2.2f).toInt(); gx = (rnd(q) - 0.5f) * 1.5f; gy = (rnd(q + 50) - 0.5f) * 1.1f }
        else if (listening) { gx *= 0.25f; gy *= 0.25f }
        else if (wander && st == 0) { gx += sin(t * 0.8f) * 0.12f; gy += cos(t * 0.6f) * 0.08f }
        val yaw = gx.coerceIn(-1f, 1f) * 0.62f
        val pitch = gy.coerceIn(-1f, 1f) * 0.44f

        val openK = sp.open
        val lidShape = openK < 0.99f || blink > 0f
        val ex = rb
        val ey = if (openK >= 0.99f) rb * (1f - blink * 0.96f) else rb * openK * (1f - blink * 0.96f)

        lensP.reset()
        if (!lidShape) lensP.addCircle(0f, 0f, rb, Path.Direction.CW)
        else {
            lensP.moveTo(-ex, 0f)
            lensP.cubicTo(-ex * 0.55f, -ey * 1.34f, ex * 0.55f, -ey * 1.34f, ex, 0f)
            lensP.cubicTo(ex * 0.55f, ey * 1.34f, -ex * 0.55f, ey * 1.34f, -ex, 0f)
            lensP.close()
        }

        c.save()
        c.translate(cx, cy)
        p.shader = null
        add(false)

        // pool of light behind
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, rb * 1.9f, intArrayOf(col(20f, 0.6f * glowK), col(9f, 0.28f * glowK), 0x00000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, rb * 1.9f, p)
        p.shader = null

        // orbit rings: far half behind the ball, near half in front
        val focal = rb * 4.2f
        val ax = gyIn * 0.6f + 0.9f + sin(t * 0.4f) * 0.1f
        val ay = -gxIn * 0.6f + spin * 0.12f
        fun turn(x: Float, y: Float, z: Float, out: FloatArray) {
            val y1 = y * cos(ax) - z * sin(ax)
            val z1 = y * sin(ax) + z * cos(ax)
            out[0] = x * cos(ay) + z1 * sin(ay)
            out[1] = y1
            out[2] = -x * sin(ay) + z1 * cos(ay)
        }
        val tmp = FloatArray(3)
        fun orbits(front: Boolean) {
            if (sp.aura != "orbit" && sp.aura != "halo") return
            val rings = if (sp.aura == "halo") 1 else 3
            add(true)
            p.strokeCap = Paint.Cap.BUTT
            for (k in 0 until rings) {
                val r = rb * (if (sp.aura == "halo") 1.12f else 1.06f + k * 0.07f)
                val kz = k * PI_F / 3f
                var px = 0f; var py = 0f; var pf = false; var have = false
                for (i in 0..90) {
                    val a = i / 90f * TAU + spin * (0.3f + k * 0.1f) * (if (k % 2 == 1) -1f else 1f)
                    val x = cos(a) * r
                    val y0 = sin(a) * r
                    val y1 = y0 * cos(0.5f)
                    val z1 = y0 * sin(0.5f)
                    turn(x * cos(kz) - y1 * sin(kz), x * sin(kz) + y1 * cos(kz), z1, tmp)
                    val qd = focal / (focal - tmp[2])
                    val xx = tmp[0] * qd
                    val yy = tmp[1] * qd
                    val isFront = tmp[2] >= 0f
                    if (have && isFront == front && pf == front) {
                        val nr = 0.4f + 0.6f * (tmp[2] / r * 0.5f + 0.5f)
                        stroke((if (sp.aura == "halo") 4f else 2.4f) * (0.6f + 0.4f * nr) * qd, col(68f, (if (front) 0.9f else 0.35f) * nr, k * 25f))
                        line(c, px, py, xx, yy)
                    }
                    px = xx; py = yy; pf = isFront; have = true
                }
            }
            add(false)
        }
        if (sp.aura == "flame") {
            add(true)
            val heat = 1f + (if (listening) lv * 1.2f else 0f) + (if (speaking) 0.4f * abs(sin(t * 8f)) else 0f)
            for (layer in 0 until 2) for (i in 0 until 28) {
                val a = i / 28f * TAU
                val k = if (layer == 1) 0.6f else 1f
                val dx = cos(a); val dy = sin(a); val px = -dy; val py = dx
                val bx = dx * rb * 0.97f; val by = dy * rb * 0.97f
                val len = rb * (0.12f + 0.2f * (0.5f + 0.5f * noise(t * 2.2f + i * 1.7f))) * heat * k
                val wd = rb * 0.06f * k
                val sw = noise(t * 3f + i * 0.9f) * rb * 0.06f * k
                path.reset()
                path.moveTo(bx - px * wd, by - py * wd)
                path.quadTo(bx + dx * len * 0.5f + px * sw, by + dy * len * 0.5f + py * sw, bx + dx * len + px * sw * 1.5f, by + dy * len + py * sw * 1.5f)
                path.quadTo(bx + dx * len * 0.5f + px * sw + px * wd * 0.5f, by + dy * len * 0.5f + py * sw + py * wd * 0.5f, bx + px * wd, by + py * wd)
                path.close()
                fill(if (layer == 1) col(72f, 0.5f, 35f) else col(58f, 0.26f))
                c.drawPath(path, p)
            }
            add(false)
        }
        orbits(false)

        // glow round the ball
        add(true)
        p.strokeJoin = Paint.Join.ROUND
        glowStroke(c, 2f, col(60f, 0.5f), glowK) { c.drawPath(lensP, p) }
        add(false)

        // ---- the ball
        c.save()
        c.clipPath(lensP)
        val hh = hue
        val sg: RadialGradient = when (sp.sclera) {
            "white" -> RadialGradient(-rb * 0.3f, -rb * 0.36f, rb * 1.3f, intArrayOf(hsl(hh, 25f, 98f, 1f), hsl(hh, 22f, 84f, 1f), hsl(hh, 30f, 48f, 1f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
            "dark" -> RadialGradient(-rb * 0.3f, -rb * 0.36f, rb * 1.3f, intArrayOf(col(14f, 1f, 0f, 40f), col(3f, 1f, 0f, 40f)), null, Shader.TileMode.CLAMP)
            "red" -> RadialGradient(-rb * 0.3f, -rb * 0.36f, rb * 1.3f, intArrayOf(hsl(0f, 75f, 52f, 1f), hsl(0f, 80f, 30f, 1f), hsl(0f, 85f, 10f, 1f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
            "black" -> RadialGradient(-rb * 0.3f, -rb * 0.36f, rb * 1.3f, intArrayOf(hsl(hh, 30f, 10f, 1f), hsl(hh, 40f, 2f, 1f)), null, Shader.TileMode.CLAMP)
            "glow" -> RadialGradient(-rb * 0.3f, -rb * 0.36f, rb * 1.3f, intArrayOf(col(92f, 1f, 0f, 60f), col(70f, 1f, 0f, 80f), col(36f, 1f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
            else -> RadialGradient(-rb * 0.3f, -rb * 0.36f, rb * 1.3f, intArrayOf(col(22f, 1f), col(5f, 1f)), null, Shader.TileMode.CLAMP)
        }
        p.style = Paint.Style.FILL
        p.shader = sg
        c.drawRect(-rb * 1.3f, -rb * 1.3f, rb * 1.3f, rb * 1.3f, p)
        p.shader = null

        if (sp.veins) {
            c.save()
            c.translate(-yaw * rb * 0.12f, -pitch * rb * 0.12f)
            c.scale(rb, rb)
            p.style = Paint.Style.STROKE
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.argb(102, 190, 40, 50)
            val vs = veinSegs(sp.seed)
            var i = 0
            while (i < vs.size) {
                p.strokeWidth = vs[i + 4] / 140f * 1.4f * 1.0f
                c.drawLine(vs[i], vs[i + 1], vs[i + 2], vs[i + 3], p)
                i += 5
            }
            c.restore()
        }

        // ---- the iris, on the surface of the ball
        val ir = rb * sp.ir * (1f + (if (listening) lv * 0.04f else 0f))
        val icx = sin(yaw) * rb * 0.68f
        val icy = sin(pitch) * rb * 0.6f
        val ct = max(0.5f, cos(yaw) * cos(pitch))
        val angDeg = atan2(icy, icx) * 180f / PI_F
        c.save()
        c.translate(icx, icy)
        c.rotate(angDeg)
        c.scale(ct, 1f)
        c.rotate(-angDeg)
        val glowUp = if (listening) 1f + lv * 0.35f else 1f
        c.save()
        path.reset(); path.addCircle(0f, 0f, ir, Path.Direction.CW)
        c.clipPath(path)
        val type = sp.iris
        p.style = Paint.Style.FILL
        if (type == "anime") {
            p.shader = LinearGradient(0f, -ir, 0f, ir, intArrayOf(col(9f, 1f), col(30f, 1f), col(64f * glowUp, 1f, 25f)), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        } else {
            p.shader = RadialGradient(0f, 0f, ir, intArrayOf(col(60f * glowUp, 1f, 8f), col(60f * glowUp, 1f, 8f), col(38f * glowUp, 1f), col(11f, 1f)), floatArrayOf(0f, 0.2f, 0.64f, 1f), Shader.TileMode.CLAMP)
        }
        c.drawRect(-ir, -ir, ir, ir, p)
        p.shader = null
        add(true)
        val sd = sp.seed
        fun ri(i: Int): Float = rnd(i + sd * 17)
        p.strokeCap = Paint.Cap.BUTT
        when (type) {
            "fibre" -> {
                for (i in 0 until 150) {
                    val a = i / 150f * TAU + ri(i) * 0.05f + spin * 0.03f
                    val r1 = ir * (0.22f + ri(i + 9) * 0.08f)
                    val r2 = ir * (0.62f + 0.36f * ri(i + 5))
                    stroke(1f, col(48f + 32f * ri(i + 3), 0.1f + 0.4f * ri(i + 8), 12f * ri(i + 2)))
                    p.strokeWidth = max(1f, u)
                    line(c, cos(a) * r1, sin(a) * r1, cos(a) * r2, sin(a) * r2)
                }
                add(false)
                for (j in 0 until 12) {
                    val a2 = ri(j + 60) * TAU
                    val rr = ir * (0.4f + 0.2f * ri(j + 70))
                    fill(Color.argb(46, 0, 0, 0))
                    c.save(); c.translate(cos(a2) * rr, sin(a2) * rr); c.rotate(a2 * 180f / PI_F)
                    oval(c, 0f, 0f, ir * 0.07f, ir * 0.03f); c.restore()
                }
                add(true)
                stroke(1.2f, col(70f, 0.35f)); c.drawCircle(0f, 0f, ir * 0.42f, p)
            }
            "anime" -> {
                add(false)
                p.style = Paint.Style.FILL
                p.shader = RadialGradient(0f, -ir * 0.6f, ir * 1.1f, intArrayOf(Color.argb(191, 0, 0, 10), Color.argb(0, 0, 0, 10)), null, Shader.TileMode.CLAMP)
                c.drawRect(-ir, -ir, ir, ir, p)
                p.shader = null
                add(true)
                for (i in 0 until 60) {
                    val a = i / 60f * TAU
                    stroke(1.1f, col(70f, 0.07f + 0.2f * ri(i), 20f))
                    line(c, cos(a) * ir * 0.35f, sin(a) * ir * 0.35f, cos(a) * ir * 0.97f, sin(a) * ir * 0.97f)
                }
            }
            "rings" -> {
                for (k in 1..5) {
                    val rr = ir * (0.3f + k * 0.13f)
                    stroke(2f, col(62f, 0.5f - k * 0.05f))
                    p.pathEffect = DashPathEffect(floatArrayOf(rr * 0.5f, rr * 0.25f + k * 3f), -spin * 30f * (if (k % 2 == 1) 1f else -1f))
                    c.drawCircle(0f, 0f, rr, p)
                    p.pathEffect = null
                }
            }
            "galaxy" -> {
                for (i in 0 until 260) {
                    val rf0 = rnd(i + sd * 17).pow(0.7f)
                    val a = (i % 3) * TAU / 3f + rf0 * 4f + spin * (1.2f - rf0) * 0.5f + (ri(i + 300) - 0.5f) * 0.4f
                    fill(col(75f, 0.3f + 0.6f * ri(i + 4), (1f - rf0) * 50f))
                    val s = (0.8f + 1.8f * ri(i + 9)) * u
                    c.drawRect(cos(a) * ir * rf0 - s / 2f, sin(a) * ir * rf0 - s / 2f, cos(a) * ir * rf0 + s / 2f, sin(a) * ir * rf0 + s / 2f, p)
                }
            }
            "flower" -> {
                for (i in 0 until 12) {
                    c.save(); c.rotate((i * TAU / 12f + spin * 0.1f) * 180f / PI_F)
                    fill(col(55f, 0.22f, (i % 2) * 20f)); oval(c, ir * 0.55f, 0f, ir * 0.42f, ir * 0.1f)
                    stroke(1f, col(72f, 0.4f)); oval(c, ir * 0.55f, 0f, ir * 0.42f, ir * 0.1f)
                    c.restore()
                }
            }
            "fire" -> {
                for (i in 0 until 26) {
                    val a = i / 26f * TAU
                    stroke(2.2f, col(60f + 25f * ri(i), 0.5f, 30f * ri(i + 3)))
                    path.reset()
                    for (s in 0..8) {
                        val uu = s / 8f
                        val rr = ir * (0.2f + 0.8f * uu)
                        val aa = a + sin(uu * 5f + t * 4f + i) * 0.09f
                        if (s == 0) path.moveTo(cos(aa) * rr, sin(aa) * rr) else path.lineTo(cos(aa) * rr, sin(aa) * rr)
                    }
                    c.drawPath(path, p)
                }
            }
            "circuit" -> {
                stroke(1.2f, col(60f, 0.5f))
                for (k in 1..4) c.drawCircle(0f, 0f, ir * k * 0.22f, p)
                for (i in 0 until 24) {
                    val a = i / 24f * TAU
                    line(c, cos(a) * ir * 0.25f, sin(a) * ir * 0.25f, cos(a) * ir * 0.9f, sin(a) * ir * 0.9f)
                }
                for (i in 0 until 14) {
                    val a = ri(i) * TAU
                    val rr = ir * (0.3f + 0.6f * ri(i + 3))
                    val lit = 0.5f + 0.5f * sin(t * 3f + i * 2f)
                    fill(col(85f, 0.3f + 0.7f * lit)); c.drawCircle(cos(a) * rr, sin(a) * rr, 2.2f * u, p)
                }
            }
            "swirl" -> {
                p.strokeCap = Paint.Cap.ROUND
                for (arm in 0 until 3) {
                    stroke(ir * 0.07f / u, col(62f, 0.6f, arm * 20f))
                    path.reset()
                    for (s in 0..60) {
                        val uu = s / 60f
                        val a = uu * 7f - spin * 1.2f + arm * TAU / 3f
                        val rr = ir * uu * 0.97f
                        if (s == 0) path.moveTo(cos(a) * rr, sin(a) * rr) else path.lineTo(cos(a) * rr, sin(a) * rr)
                    }
                    c.drawPath(path, p)
                }
                p.strokeCap = Paint.Cap.BUTT
            }
            "aperture" -> {
                stroke(1.6f, col(62f, 0.7f))
                for (i in 0 until 8) {
                    val a = i * TAU / 8f + spin * 0.1f
                    line(c, cos(a) * ir * 0.3f, sin(a) * ir * 0.3f, cos(a + 0.9f) * ir, sin(a + 0.9f) * ir)
                    val rr = ir * (0.35f + 0.1f * (i % 2))
                    rf.set(-rr, -rr, rr, rr)
                    c.drawArc(rf, a * 180f / PI_F, 0.5f * 180f / PI_F, false, p)
                }
            }
        }
        add(false)
        // dark rim at the edge of the iris, so it sits on the ball
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, ir, intArrayOf(0x00000000, 0x00000000, Color.argb((sp.limbal * 255f).toInt().coerceIn(0, 255), 0, 0, 0)), floatArrayOf(0f, 0.78f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(-ir, -ir, ir, ir, p)
        p.shader = null
        c.restore()

        // ---- pupil
        val dil = sp.pupil * (1f + 0.05f * sin(t * 2f) + (if (listening) lv * 0.4f else 0f) + (if (speaking) 0.14f * sin(t * 12f) else 0f)) * (if (thinking) 0.78f else 1f)
        val pr = ir * dil
        fill(Color.argb(255, 0, 2, 6))
        path.reset()
        var drawPupil = true
        when (sp.shape) {
            "round" -> path.addCircle(0f, 0f, pr, Path.Direction.CW)
            "slit" -> { val w = max(1.5f * u, pr * (if (listening) 0.9f else 0.34f)); path.addOval(RectF(-w, -ir * 0.92f, w, ir * 0.92f), Path.Direction.CW) }
            "hslit" -> { val h = max(1.5f * u, pr * 0.42f); path.addOval(RectF(-ir * 0.78f, -h, ir * 0.78f, h), Path.Direction.CW) }
            "star", "cross" -> {
                val n = if (sp.shape == "star") 5 else 4
                val inner = if (sp.shape == "star") 0.45f else 0.28f
                for (i in 0 until n * 2) {
                    val a = spin * 0.4f + i * PI_F / n - PI_F / 2f
                    val rr = (if (i % 2 == 1) inner else 1f) * pr * 1.25f
                    if (i == 0) path.moveTo(cos(a) * rr, sin(a) * rr) else path.lineTo(cos(a) * rr, sin(a) * rr)
                }
                path.close()
            }
            "heart" -> {
                val s = pr * 0.95f * (1f + 0.12f * max(0f, sin(t * 6f)))
                path.moveTo(0f, s * 0.9f)
                path.cubicTo(-s * 1.5f, -s * 0.1f, -s * 0.9f, -s * 1.2f, 0f, -s * 0.5f)
                path.cubicTo(s * 0.9f, -s * 1.2f, s * 1.5f, -s * 0.1f, 0f, s * 0.9f)
                path.close()
            }
            "diamond" -> { path.moveTo(0f, -pr * 1.3f); path.lineTo(pr * 0.85f, 0f); path.lineTo(0f, pr * 1.3f); path.lineTo(-pr * 0.85f, 0f); path.close() }
            "keyhole" -> {
                path.addCircle(0f, -pr * 0.25f, pr * 0.7f, Path.Direction.CW)
                path.moveTo(-pr * 0.35f, pr * 0.2f); path.lineTo(-pr * 0.6f, pr * 1.1f); path.lineTo(pr * 0.6f, pr * 1.1f); path.lineTo(pr * 0.35f, pr * 0.2f); path.close()
            }
            else -> drawPupil = false
        }
        if (drawPupil) {
            c.drawPath(path, p)
            add(true)
            stroke(1.6f, col(70f, 0.55f))
            c.drawPath(path, p)
            add(false)
        }
        c.restore() // back to the ball

        // ball shading: darker toward the edge so it curves away
        val shade = 1f
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, rb * 1.02f, intArrayOf(0x00000000, 0x00000000, Color.argb((0.62f * shade * 255f).toInt(), 0, 4, 12)), floatArrayOf(0f, 0.54f, 1f), Shader.TileMode.CLAMP)
        c.drawRect(-rb * 1.2f, -rb * 1.2f, rb * 1.2f, rb * 1.2f, p)
        p.shader = null
        add(true)
        rf.set(-rb * 0.93f, -rb * 0.93f, rb * 0.93f, rb * 0.93f)
        stroke(2.5f, col(70f, 0.28f))
        c.drawArc(rf, 0.35f * 180f / PI_F, (1.9f - 0.35f) * 180f / PI_F, false, p)
        add(false)
        if (lidShape) {
            p.style = Paint.Style.FILL
            p.shader = LinearGradient(0f, -ey, 0f, ey, intArrayOf(Color.argb(179, 0, 3, 10), 0x00000000, 0x00000000, Color.argb(89, 0, 3, 10)), floatArrayOf(0f, 0.4f, 0.85f, 1f), Shader.TileMode.CLAMP)
            c.drawRect(-ex, -rb, ex, rb, p)
            p.shader = null
        }
        // glass: highlights stay where the light is while the iris slides under them
        val hx = -rb * 0.32f - yaw * rb * 0.05f
        val hy = -rb * 0.34f - pitch * rb * 0.05f
        when (sp.hl) {
            "window" -> {
                c.save(); c.translate(hx, hy); c.rotate(-0.5f * 180f / PI_F)
                p.style = Paint.Style.FILL
                p.shader = LinearGradient(-rb * 0.2f, 0f, rb * 0.2f, 0f, intArrayOf(Color.argb(204, 255, 255, 255), Color.argb(64, 255, 255, 255)), null, Shader.TileMode.CLAMP)
                oval(c, 0f, 0f, rb * 0.2f, rb * 0.12f)
                p.shader = null
                c.restore()
                fill(Color.argb(128, 255, 255, 255)); c.drawCircle(rb * 0.37f, rb * 0.55f, rb * 0.04f, p)
            }
            "round", "sparkle" -> {
                val bob = if (speaking) sin(t * 9f) * rb * 0.02f else 0f
                c.save(); c.translate(hx + icx * 0.3f, hy + icy * 0.3f + bob); c.rotate(-0.5f * 180f / PI_F)
                fill(Color.argb(242, 255, 255, 255)); oval(c, 0f, 0f, rb * 0.13f, rb * 0.11f)
                c.restore()
                fill(Color.argb(204, 255, 255, 255)); c.drawCircle(-hx * 0.8f + icx * 0.3f, -hy * 0.8f + icy * 0.3f - bob, rb * 0.05f, p)
                if (sp.hl == "sparkle") for (k in 0 until 4) {
                    val tw = 0.5f + 0.5f * sin(t * 3f + k * 2.1f)
                    val sx = icx + cos(k * 1.9f + 1f) * ir * 0.62f
                    val sy = icy + sin(k * 1.9f + 1f) * ir * 0.5f
                    val sr = rb * 0.025f * (0.5f + tw)
                    fill(Color.argb(((0.35f + 0.6f * tw) * 255f).toInt().coerceIn(0, 255), 255, 255, 255))
                    star4(c, sx, sy, sr * 1.15f)
                }
            }
        }
        c.restore() // end of the lens clip

        // lids drawn on top
        val lid = if (sp.lid == "auto") (if (lidShape) "soft" else "none") else sp.lid
        if (lid != "none") {
            add(true)
            p.strokeCap = Paint.Cap.ROUND
            path.reset()
            path.moveTo(-ex, 0f); path.cubicTo(-ex * 0.55f, -ey * 1.34f, ex * 0.55f, -ey * 1.34f, ex, 0f)
            val thick = lid == "thick" || lid == "lash"
            glowStroke(c, if (thick) 5f else 2.4f, col(68f, 0.95f), glowK) { c.drawPath(path, p) }
            path.reset()
            path.moveTo(-ex, 0f); path.cubicTo(-ex * 0.55f, ey * 1.34f, ex * 0.55f, ey * 1.34f, ex, 0f)
            stroke(1.6f, col(66f, 0.55f)); c.drawPath(path, p)
            if (lid == "lash") {
                stroke(3f, col(70f, 0.95f))
                for (k in 0 until 3) {
                    val uu = 0.02f + k * 0.09f
                    val m = 1f - uu
                    val bx = m * m * m * -ex + 3f * m * m * uu * -0.55f * ex + 3f * m * uu * uu * 0.55f * ex + uu * uu * uu * ex
                    val by = 3f * m * m * uu * -1.34f * ey + 3f * m * uu * uu * -1.34f * ey
                    line(c, bx, by, bx - ex * (0.16f - k * 0.03f), by - ey * (0.2f + k * 0.03f))
                }
            }
            add(false)
        } else if (!lidShape) {
            add(true)
            stroke(1.6f, col(66f, 0.4f)); c.drawCircle(0f, 0f, rb, p)
            add(false)
        }
        if (sp.aura == "sparkles") {
            add(true)
            for (i in 0 until 12) {
                val a = i / 12f * TAU + spin * 0.12f * (if (i % 2 == 1) 1f else -1f)
                val rr = rb * (1.1f + 0.28f * rnd(i))
                val tw = 0.5f + 0.5f * sin(t * 3f + i * 1.7f)
                val s = rb * (0.02f + 0.03f * rnd(i + 4)) * (0.4f + tw) * (1f + (if (listening) lv else 0f))
                fill(col(82f, 0.35f + 0.6f * tw))
                star4(c, cos(a) * rr, sin(a) * rr, s)
            }
            add(false)
        }
        orbits(true)
        c.restore()
    }

    private val veinCache = HashMap<Int, FloatArray>()

    /** Branching little veins for the white of the eye, drawn once per seed. Five numbers per piece: x1 y1 x2 y2 width. */
    private fun veinSegs(seed: Int): FloatArray {
        veinCache[seed]?.let { return it }
        val out = ArrayList<Float>()
        fun r(i: Int): Float {
            val x = sin(i * 91.7 + seed * 13.1) * 43758.5453
            return (x - floor(x)).toFloat()
        }
        var n = 0
        fun branch(x: Float, y: Float, a: Float, len: Float, wd: Float, depth: Int) {
            if (depth > 3 || len < 0.03f) return
            val x2 = x + cos(a) * len
            val y2 = y + sin(a) * len
            out.add(x); out.add(y); out.add(x2); out.add(y2); out.add(wd)
            n++
            val here = n
            branch(x2, y2, a + (r(here * 3) - 0.5f) * 0.7f, len * 0.78f, wd * 0.7f, depth + 1)
            if (r(here * 5) > 0.35f) branch(x2, y2, a + 0.5f + r(here * 7) * 0.5f, len * 0.6f, wd * 0.6f, depth + 1)
            if (r(here * 11) > 0.6f) branch(x2, y2, a - 0.5f - r(here * 13) * 0.5f, len * 0.55f, wd * 0.55f, depth + 1)
        }
        for (i in 0 until 9) {
            val a = r(i + 1) * TAU
            branch(cos(a) * 0.97f, sin(a) * 0.97f, a + PI_F + (r(i + 40) - 0.5f) * 0.6f, 0.2f + r(i + 20) * 0.12f, 1.3f, 0)
        }
        val arr = out.toFloatArray()
        veinCache[seed] = arr
        return arr
    }
}

/** The 3D Jarvis from the Eye Lab: tilted rings with near and far sides, ticks, a shaded iris, glass. */
class Jarvis3D {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val out = FloatArray(3)
    private var hue = 200f
    private var u = 1f

    private fun col(l: Float, a: Float, dh: Float = 0f): Int = hsl(hue + dh, 100f, l, a)
    private fun add(on: Boolean) { p.blendMode = if (on) BlendMode.PLUS else BlendMode.SRC_OVER }
    private fun stroke(w: Float, color: Int) { p.style = Paint.Style.STROKE; p.strokeWidth = w * u; p.color = color; p.shader = null }

    fun draw(
        c: Canvas, cx: Float, cy: Float, r: Float, t: Float, spin: Float, gx: Float, gy: Float,
        st: Int, lv: Float, blink: Float, wander: Boolean, userHue: Float, glowK: Float
    ) {
        hue = userHue
        u = r / 150f
        val listening = st == 1
        val thinking = st == 2
        val speaking = st == 3
        val par0x = gx * r * 0.09f
        val par0y = gy * r * 0.09f
        val squash = 1f - blink * 0.9f
        val focal = r * 3.2f
        c.save()
        c.translate(cx, cy)
        add(false)

        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, r * 1.65f, intArrayOf(col(20f, 0.6f * glowK), col(9f, 0.28f * glowK), 0x00000000), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, r * 1.65f, p)
        p.shader = null

        fun angX(k: Float) = gy * 0.7f * (1f + 0.25f * k) + sin(t * 0.45f + k * 2f) * 0.1f
        fun angY(k: Float) = -gx * 0.7f * (1f - 0.2f * k) + cos(t * 0.37f + k * 3f) * 0.1f
        fun spin3(x: Float, y: Float, z: Float, rx: Float, ry: Float) {
            val y1 = y * cos(rx) - z * sin(rx)
            val z1 = y * sin(rx) + z * cos(rx)
            out[0] = x * cos(ry) + z1 * sin(ry)
            out[1] = y1
            out[2] = -x * sin(ry) + z1 * cos(ry)
        }
        fun nearK(z: Float, rr: Float) = 0.35f + 0.65f * (z / rr * 0.5f + 0.5f)

        // one arc of a ring in 3D, drawn in short pieces so near parts are brighter
        fun arc3(rr: Float, a0: Float, a1: Float, k: Float, width: Float, lum: Float, alpha: Float, dh: Float) {
            val rx = angX(k)
            val ry = angY(k)
            val n = max(2, kotlin.math.ceil(abs(a1 - a0) / 0.1f).toInt())
            var px = 0f; var py = 0f; var pn = 0f; var have = false
            for (i in 0..n) {
                val a = a0 + (a1 - a0) * i / n
                spin3(cos(a) * rr, sin(a) * rr, 0f, rx, ry)
                val q = focal / (focal - out[2])
                val x = out[0] * q
                val y = out[1] * q
                val nr = nearK(out[2], rr)
                if (have) {
                    val m = (nr + pn) / 2f
                    if (glowK > 0f) { stroke(width * 3.4f * (0.6f + 0.4f * m), col(60f, 0.16f * alpha * m * glowK, dh)); c.drawLine(px, py, x, y, p) }
                    stroke(width * (0.6f + 0.4f * m), col(lum, alpha * m, dh)); c.drawLine(px, py, x, y, p)
                }
                px = x; py = y; pn = nr; have = true
            }
        }

        add(true)
        p.strokeCap = Paint.Cap.BUTT
        val a1 = 0.2f
        arc3(r * 0.97f, 0f, TAU, a1, 1.2f, 65f, 0.4f, 0f)
        for (i in 0 until 24) { val a = -spin * 0.9f + i * (TAU / 24f); arc3(r * 0.9f, a, a + 0.16f, a1, 2.6f, 65f, 0.8f, 0f) }
        // ticks
        val rx2 = angX(0.5f)
        val ry2 = angY(0.5f)
        for (i in 0 until 72) {
            val a = i * (TAU / 72f) + spin * 0.07f
            val long = i % 6 == 0
            val r1 = r * 0.8f
            val r2 = r1 - (if (long) 11f else 5f) * u
            spin3(cos(a) * r1, sin(a) * r1, 0f, rx2, ry2)
            val q1 = focal / (focal - out[2]); val x1 = out[0] * q1; val y1 = out[1] * q1; val nr = nearK(out[2], r1)
            spin3(cos(a) * r2, sin(a) * r2, 0f, rx2, ry2)
            val q2 = focal / (focal - out[2]); val x2 = out[0] * q2; val y2 = out[1] * q2
            stroke((if (long) 2.2f else 1.1f) * (0.6f + 0.4f * nr), col(70f, (if (long) 0.85f else 0.4f) * nr))
            c.drawLine(x1, y1, x2, y2, p)
        }
        val a3 = spin * 0.38f
        arc3(r * 0.68f, a3, a3 + 1.4f, 0.9f, 5.5f, 66f, 0.95f, 0f)
        arc3(r * 0.68f, a3 + 2.45f, a3 + 3.3f, 0.9f, 5.5f, 66f, 0.7f, 0f)
        arc3(r * 0.68f, a3 + 4.4f, a3 + 4.9f, 0.9f, 5.5f, 66f, 0.85f, 70f)
        if (thinking) {
            arc3(r * 0.58f, spin * 1.2f, spin * 1.2f + 0.5f, 1.3f, 3.5f, 85f, 1f, 0f)
            arc3(r * 0.58f, spin * 1.2f + PI_F, spin * 1.2f + PI_F + 0.5f, 1.3f, 3.5f, 85f, 1f, 0f)
        }
        add(false)

        // voice bars while listening
        if (listening) {
            add(true)
            stroke(2.4f, col(70f, 0.8f))
            for (i in 0 until 56) {
                val a = i * (TAU / 56f)
                val len = r * (0.03f + lv * 0.1f * (0.4f + 0.6f * abs(sin(i * 1.3f + t * 6f))))
                val r1 = r * 0.57f
                c.drawLine(cos(a) * r1, sin(a) * r1, cos(a) * (r1 + len), sin(a) * (r1 + len), p)
            }
            add(false)
        }

        // floating dots in 3D
        add(true)
        val rxd = angX(1.1f)
        val ryd = angY(1.1f)
        for (i in 0 until 22) {
            val th = t * (0.12f + rnd(i) * 0.3f) * (if (i % 2 == 1) 1f else -1f) + rnd(i + 30) * TAU
            val ph = (rnd(i + 17) - 0.5f) * 2.2f
            val rr = r * (0.6f + 0.42f * rnd(i + 9))
            spin3(rr * cos(ph) * cos(th), rr * sin(ph), rr * cos(ph) * sin(th), rxd, ryd)
            val q = focal / (focal - out[2])
            val nr = nearK(out[2], rr)
            p.style = Paint.Style.FILL; p.shader = null
            p.color = col(75f, (0.25f + 0.55f * rnd(i + 4)) * nr)
            c.drawCircle(out[0] * q, out[1] * q, (1f + 2.2f * rnd(i + 3)) * q * (0.7f + 0.5f * nr) * u, p)
        }
        add(false)

        // iris: a shaded sphere with fibres, a bright rim and a dark edge
        val ir = r * 0.52f
        c.save()
        c.translate(par0x, par0y)
        c.scale(1f, squash)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(-ir * 0.25f, -ir * 0.3f, ir * 1.1f, intArrayOf(col(42f, 0.6f), col(22f, 0.65f), col(8f, 0.9f)), floatArrayOf(0f, 0.6f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, ir, p)
        p.shader = null
        add(true)
        for (i in 0 until 110) {
            val a = i / 110f * TAU + spin * 0.15f + rnd(i) * 0.05f
            val r1 = r * 0.2f + rnd(i + 50) * r * 0.06f
            val r2 = ir * (0.78f + 0.22f * rnd(i + 100)) + (if (listening) lv * r * 0.08f * rnd(i + 7) else 0f)
            stroke(1.2f, col(55f + 25f * rnd(i + 3), 0.16f + 0.42f * rnd(i + 9)))
            c.drawLine(cos(a) * r1, sin(a) * r1, cos(a) * r2, sin(a) * r2, p)
        }
        stroke(2.4f, col(66f, 0.95f)); c.drawCircle(0f, 0f, ir, p)
        stroke(1.2f, col(72f, 0.55f)); c.drawCircle(0f, 0f, r * 0.3f, p)
        add(false)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, ir, intArrayOf(0x00000000, 0x00000000, Color.argb(153, 0, 6, 14)), floatArrayOf(0f, 0.78f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, ir, p)
        p.shader = null
        c.restore()

        // pupil: in front, so it moves the most
        val wx = if (wander && st == 0) sin(t * 0.9f) * r * 0.05f else 0f
        val wy = if (wander && st == 0) cos(t * 0.7f) * r * 0.03f else 0f
        val pr = r * 0.17f * (1f + 0.06f * sin(t * 2.2f) + (if (speaking) 0.16f * sin(t * 13f) else 0f) + (if (listening) lv * 0.25f else 0f))
        c.save()
        c.translate(par0x * 1.7f + wx, par0y * 1.7f + wy)
        c.scale(1f, squash)
        add(true)
        stroke(2.6f, col(72f, 0.95f)); c.drawCircle(0f, 0f, pr, p)
        add(false)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(0f, 0f, pr, intArrayOf(Color.argb(255, 0, 3, 8), Color.argb(250, 0, 6, 14), col(16f, 0.9f)), floatArrayOf(0f, 0.75f, 1f), Shader.TileMode.CLAMP)
        c.drawCircle(0f, 0f, pr * 0.98f, p)
        p.shader = null
        c.restore()

        // glass highlight that slides the other way
        c.save()
        c.translate(-par0x * 0.7f, -par0y * 0.7f)
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(-r * 0.2f, -r * 0.24f, r * 0.3f, intArrayOf(Color.argb(97, 255, 255, 255), 0x00FFFFFF), null, Shader.TileMode.CLAMP)
        c.save(); c.translate(-r * 0.2f, -r * 0.24f); c.rotate(-0.6f * 180f / PI_F); c.translate(r * 0.2f, r * 0.24f)
        c.drawOval(RectF(-r * 0.2f - r * 0.3f, -r * 0.24f - r * 0.2f, -r * 0.2f + r * 0.3f, -r * 0.24f + r * 0.2f), p)
        c.restore()
        p.shader = null
        stroke(2f, Color.argb(71, 255, 255, 255))
        val rf = RectF(-r * 0.58f, -r * 0.58f, r * 0.58f, r * 0.58f)
        c.drawArc(rf, 3.55f * 180f / PI_F, 0.8f * 180f / PI_F, false, p)
        p.style = Paint.Style.FILL; p.color = Color.argb(217, 255, 255, 255)
        c.drawCircle(-r * 0.09f, -r * 0.1f, r * 0.018f, p)
        c.restore()
        c.restore()
    }
}


/** Draws any eye from the library (or the 3D Jarvis) on a canvas. Used by the real eye and by the preview. */
class EyeFace {
    private val sphere = EyeSphere()
    private val j3 = Jarvis3D()
    private val hsv = FloatArray(3)

    /** st: 0 waiting, 1 listening, 2 thinking, 3 speaking. alpha 0..1 fades the whole eye. */
    fun draw(c: Canvas, style: String, cx: Float, cy: Float, r: Float, t: Float, spin: Float, gx: Float, gy: Float, st: Int, lv: Float, blink: Float, alpha: Float) {
        val lib = EyeLib.find(style)
        Color.colorToHSV(Colours.eyeRgb(), hsv)
        val own = Store.b("eyeown", false)
        val glow = Store.f("eyeglow", 1f)
        val wander = Store.b("eyewander", true)
        val n = c.saveLayerAlpha(cx - r * 2f, cy - r * 2f, cx + r * 2f, cy + r * 2f, (alpha * 255f).toInt().coerceIn(0, 255))
        if (lib != null) sphere.draw(c, lib.spec, cx, cy, r * 0.87f, t, spin, gx, gy, st, lv, blink, wander, hsv[0], own, glow)
        else j3.draw(c, cx, cy, r, t, spin, gx, gy, st, lv, blink, wander, hsv[0], glow)
        c.restoreToCount(n)
    }

    companion object {
        /** Styles drawn by EyeFace rather than by the original EyeView code. */
        fun isNew(style: String): Boolean = style == "jarvis3d" || EyeLib.find(style) != null
    }
}
